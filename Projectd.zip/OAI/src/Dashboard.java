


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;

public class Dashboard {
	private String url = "jdbc:mysql://localhost:3306/projectd";
	private	String user = "root";
	private	String password = "";
    private JFrame frame;
    private JButton btnHome;
    private JButton btnCart;
    private JButton btnProduct;
    private JButton btnPayment;
    private JButton btnOrder;
    private JPanel Product;
    private JPanel Home;
    private JPanel Cart;
    private JPanel OrderHistory;
    private JPanel Payment;
    //private JPanel Account1;
    private JTable table;
    private DefaultTableModel cartTableModel;
    
    
    int integer;
   // private JTable tableItems;
	//private int selectedIndex;
	//private AbstractButton textAreaofTotal;
	//private JTable table_1;
	//private JTable CartTable;
	private JTable table_2;
	private JPanel Account2;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextArea TextAreaAllTotal;
	private JTable PaymentTable;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textFieldEmail;
	//private JTable table_3;
	private JTextField textFieldName;
	private JTextField textFieldAddress;
	private JTextField textFieldContact;
	
//	 private void addToCartTableModel1(String productName, String selectedSize, int selectedPrice,
//             int selectedQuantity, double totalPrice) {
//// Add the data to the table model
//
//
//// Insert the data into the database
//try (Connection connect = (Connection) DriverManager.getConnection(url, user, password)) {
//String sql = "SELECT INTO products (productname, selectedSize, sellprice, quantity,total_price )"
//+ " VALUES (?, ?, ?, ?, sellprice *quantity)";
//
//
//try (PreparedStatement prepStat = (PreparedStatement) connect.prepareStatement(sql)) {
//prepStat.setString(1, productName);
//prepStat.setString(2, selectedSize);
//prepStat.setInt(3, selectedPrice);
//prepStat.setInt(4, selectedQuantity);
//prepStat.setDouble(5, totalPrice);
//
//int rowsAffected = prepStat.executeUpdate();
//
//if (rowsAffected > 0) {
//JOptionPane.showMessageDialog(null, "Added data to the database successfully");
//} else {
//JOptionPane.showMessageDialog(null, "Failed to add data to the database");
//}
//} catch (SQLException e) {
//e.printStackTrace();
//}
//} catch (SQLException e) {
//e.printStackTrace();
//}
//}
   

    public static void In() {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                	Dashboard window = new Dashboard();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Dashboard() {
        initialize();
        cartTableModel = new DefaultTableModel(new String[]{"#","Product", "Size", "Price", "Quantity", "Total", "Select","Remove"}, 0);
    }

    //@SuppressWarnings("removal")
	private void initialize() {
        frame = new JFrame();
        frame.setResizable(false);
        frame.getContentPane().setBackground(new Color(255, 255, 255));
        frame.setBounds(100, 100, 1292, 750);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
       
        frame.setLocationRelativeTo(null);

        // The panel Background-----------------------------------------------------------
        JPanel MainPanel = new JPanel();
        MainPanel.setBorder(new LineBorder(new Color(0, 128, 128), 5, true));
        MainPanel.setBackground(new Color(128, 128, 128));
        MainPanel.setBounds(0, 0, 1276, 711);
        frame.getContentPane().add(MainPanel);
        MainPanel.setLayout(null);

        //The Header Part-----------------------------------------------------------------
        JPanel pnlHeader = new JPanel();
        pnlHeader.setBounds(27, 26, 1227, 95);
        MainPanel.add(pnlHeader);
        pnlHeader.setBorder(new LineBorder(new Color(0, 128, 128), 5));
        pnlHeader.setBackground(new Color(192, 192, 192));
        pnlHeader.setLayout(null);

        JPanel pnlSearch = new JPanel();
        pnlSearch.setBounds(141, 24, 802, 49);
        pnlHeader.add(pnlSearch);
        pnlSearch.setLayout(null);

        JButton btnSearch = new JButton("Search");
        btnSearch.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		
        	}
        });
        btnSearch.setFont(new Font("Times New Roman", Font.PLAIN, 9));
        btnSearch.setFocusable(false);
        btnSearch.setBackground(new Color(128, 128, 128));
        btnSearch.setBounds(683, 12, 67, 23);
        pnlSearch.add(btnSearch);

        JPanel panel_5 = new JPanel();
        panel_5.setBackground(new Color(0, 128, 128));
        panel_5.setBounds(749, 12, 29, 23);
        pnlSearch.add(panel_5);
        
        JButton btnAccount2 = new JButton("Account");
        btnAccount2.setBounds(953, 24, 73, 49);
        pnlHeader.add(btnAccount2);
        btnAccount2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		showPanel(Account2);
        	}
        });
        btnAccount2.setFont(new Font("Georgia", Font.PLAIN, 9));
        btnAccount2.setFocusable(false);
        btnAccount2.setBorder(new LineBorder(new Color(0, 128, 128), 5));
        btnAccount2.setBackground(new Color(0, 128, 128));

        //The Part where the buttons of Home , Product, Cart, and Order History-----------------------------------------------
        JPanel pblHPCOButton = new JPanel();
        pblHPCOButton.setBounds(27, 170, 1227, 49);
        MainPanel.add(pblHPCOButton);
        pblHPCOButton.setBorder(new LineBorder(new Color(0, 128, 128), 5));
        pblHPCOButton.setBackground(new Color(192, 192, 192));
        pblHPCOButton.setLayout(null);

        
        
        //Buttons----------------------------------------------------------------
       
              btnHome = new JButton("Home");
              btnHome.setBackground(new Color(128, 128, 128));
              btnHome.setBorder(new LineBorder(new Color(0, 128, 128), 5));
              btnHome.setFocusable(false);
              btnHome.addActionListener(new ActionListener() {
                  public void actionPerformed(ActionEvent e) {
                      showPanel(Home);
                  }
              });
              btnHome.setFont(new Font("Georgia", Font.PLAIN, 15));
              btnHome.setBounds(28, 11, 86, 27);
              pblHPCOButton.add(btnHome);

              
              
              
                         btnProduct = new JButton("Product");
                         btnProduct.setBackground(new Color(128, 128, 128));
                         btnProduct.setBorder(new LineBorder(new Color(0, 128, 128), 5));
                         btnProduct.setFocusable(false);
                         btnProduct.addActionListener(new ActionListener() {
                                public void actionPerformed(ActionEvent e) {
                                     showPanel(Product);
                                }
                         });
                         btnProduct.setFont(new Font("Georgia", Font.PLAIN, 15));
                         btnProduct.setBounds(137, 11, 86, 27);
                         pblHPCOButton.add(btnProduct);

                         
                         
                         
                         
                                        btnCart = new JButton("Cart");
                                        btnCart.setBackground(new Color(128, 128, 128));
                                        btnCart.setBorder(new LineBorder(new Color(0, 128, 128), 5));
                                        btnCart.setFocusable(false);
                                        btnCart.addActionListener(new ActionListener() {
                                               public void actionPerformed(ActionEvent e) {
                                                    showPanel(Cart);
                
                                               }
                                        });
                                        btnCart.setFont(new Font("Georgia", Font.PLAIN, 15));
                                        btnCart.setBounds(246, 11, 86, 27);
                                        pblHPCOButton.add(btnCart);

                                        
                                        
                                        
                                        
                                                     btnPayment = new JButton("Order History");
                                                     btnPayment.setBackground(new Color(128, 128, 128));
                                                     btnPayment.setBorder(new LineBorder(new Color(0, 128, 128), 5));
                                                     btnPayment.setFocusable(false);
                                                     btnPayment.addActionListener(new ActionListener() {
                                                                 public void actionPerformed(ActionEvent e) {
                                                                      showPanel(OrderHistory);
                                                                 }
                                                     });
                                                     btnPayment.setFont(new Font("Georgia", Font.PLAIN, 15));
                                                     btnPayment.setBounds(482, 11, 140, 27);
                                                     pblHPCOButton.add(btnPayment);
                                                     
                                                     
                                                     btnOrder = new JButton("Payment");
                                                     btnOrder.setBackground(new Color(128, 128, 128));
                                                     btnOrder.setBorder(new LineBorder(new Color(0, 128, 128), 5));
                                                     btnOrder.setFocusable(false);
                                                     btnOrder.addActionListener(new ActionListener() {
                                                     	public void actionPerformed(ActionEvent e) {
                                                     		          showPanel(Payment);
                                                     	}
                                                     });
                                                     btnOrder.setFont(new Font("Georgia", Font.PLAIN, 15));
                                                     btnOrder.setBounds(357, 11, 100, 27);
                                                     pblHPCOButton.add(btnOrder);

                                                     
                                                     
                                                     
        //Hello Welcome Part------------------------------------------------------------                                            
        JLabel lblHelloWelcome = new JLabel("Hello Welcome");
        lblHelloWelcome.setFont(new Font("Georgia", Font.BOLD, 34));
        lblHelloWelcome.setHorizontalAlignment(SwingConstants.CENTER);
        lblHelloWelcome.setBounds(27, 123, 1227, 49);
        MainPanel.add(lblHelloWelcome);

        
        //The Part of Button Panels-----------------------------------------------------
        JLayeredPane MainPanel2 = new JLayeredPane();
        MainPanel2.setBorder(new LineBorder(new Color(0, 128, 128), 5));
        MainPanel2.setBounds(27, 242, 1227, 446);
        MainPanel.add(MainPanel2);
        MainPanel2.setLayout(new CardLayout());
        
     
        //All The Codes in Home Panel--------------------------------------------------
        Home = new JPanel();
        Home.setBackground(new Color(0, 128, 128));
        Home.setBorder(new LineBorder(new Color(0, 128, 128), 5));
        Home.setBounds(0, 0, 1227, 382);
        MainPanel2.add(Home);
        Home.setLayout(null);
        
        JPanel panel = new JPanel();
        panel.setBorder(new LineBorder(new Color(128, 128, 128), 5));
        panel.setBounds(173, 102, 844, 241);
        panel.setBackground(new Color(192, 192, 192));
        Home.add(panel);
        panel.setLayout(null);
        
        
        
                JPanel pnlWelcome = new JPanel();
                pnlWelcome.setBorder(null);
                pnlWelcome.setBounds(10, 11, 824, 100);
                panel.add(pnlWelcome);
                pnlWelcome.setLayout(null);
                

                       JLabel lblWelcome = new JLabel("WELCOME");
                       lblWelcome.setBackground(new Color(255, 255, 255));
                       lblWelcome.setHorizontalAlignment(SwingConstants.CENTER);
                       lblWelcome.setForeground(new Color(0, 128, 128));
                       lblWelcome.setFont(new Font("Georgia", Font.BOLD, 67));
                       lblWelcome.setBounds(0, -3, 844, 102);
                       pnlWelcome.add(lblWelcome);
        
                       JTextArea textAreaCustomerName = new JTextArea();
                       textAreaCustomerName.setEnabled(false);
                       textAreaCustomerName.setEditable(false);
                       textAreaCustomerName.setText(user);
                       textAreaCustomerName.setBounds(359, 77, 138, 22);
                       pnlWelcome.add(textAreaCustomerName);
        
                       
                       
                JPanel pnlInfo = new JPanel();
                pnlInfo.setBackground(new Color(192, 192, 192));
                pnlInfo.setBounds(290, 110, 281, 55);
                panel.add(pnlInfo);
                pnlInfo.setLayout(null);
        
                       JLabel lblFirst = new JLabel(" Shop Name: Clothing Paradise \r\n");
                       lblFirst.setFont(new Font("Times New Roman", Font.PLAIN, 11));
                       lblFirst.setHorizontalAlignment(SwingConstants.CENTER);
                       lblFirst.setBounds(0, 11, 281, 7);
                       pnlInfo.add(lblFirst);
        
                       JLabel lblSecond = new JLabel("Location: 123 Fashion Street, Cityville");
                       lblSecond.setHorizontalAlignment(SwingConstants.CENTER);
                       lblSecond.setFont(new Font("Times New Roman", Font.PLAIN, 11));
                       lblSecond.setBounds(0, 22, 281, 7);
                       pnlInfo.add(lblSecond);
        
                       JLabel lblThird = new JLabel("Contact: +1 (123) 456-7890");
                       lblThird.setFont(new Font("Times New Roman", Font.PLAIN, 11));
                       lblThird.setHorizontalAlignment(SwingConstants.CENTER);
                       lblThird.setBounds(0, 33, 281, 7);
                       pnlInfo.add(lblThird);
        
                       
                                           
               JPanel pnlAboutUs = new JPanel();
               pnlAboutUs.setBackground(new Color(192, 192, 192));
               pnlAboutUs.setBounds(81, 175, 665, 55);
               panel.add(pnlAboutUs);
               pnlAboutUs.setLayout(null);
        
                      JLabel lbl1 = new JLabel("Clothing Paradise is your one-stop destination for the latest  fashion trends.    ");
                      lbl1.setHorizontalAlignment(SwingConstants.CENTER);
                      lbl1.setFont(new Font("Georgia", Font.BOLD, 15));
                      lbl1.setBounds(0, 0, 665, 21);
                      pnlAboutUs.add(lbl1);
        
                      JLabel lbl2 = new JLabel("We offer a wide range of stylish and comfortable clothing for every occasion.");
                      lbl2.setHorizontalAlignment(SwingConstants.CENTER);
                      lbl2.setFont(new Font("Georgia", Font.BOLD, 15));
                      lbl2.setBounds(0, 16, 665, 21);
                      pnlAboutUs.add(lbl2);
        
                      JLabel lbl3 = new JLabel("Shop with us and stay in style!     ");
                      lbl3.setHorizontalAlignment(SwingConstants.CENTER);
                      lbl3.setFont(new Font("Georgia", Font.BOLD, 15));
                      lbl3.setBounds(0, 32, 665, 18);
                      pnlAboutUs.add(lbl3);





                      
                      
                      
                      
                      
                      
                      Payment = new JPanel();
                      Payment.setBackground(new Color(0, 128, 128));
                      Payment.setBorder(new LineBorder(new Color(0, 128, 128), 5));
                      Payment.setBounds(0, 0, 1227, 382);
                      MainPanel2.add(Payment);
                      Payment.setLayout(null);
                      
                      JPanel panelforPaymentPart = new JPanel();
                      panelforPaymentPart.setLayout(null);
                      panelforPaymentPart.setBackground(Color.LIGHT_GRAY);
                      panelforPaymentPart.setBounds(10, 73, 1197, 278);
                      Payment.add(panelforPaymentPart);
                      
                      JScrollPane scrollPanePayment = new JScrollPane();
                      scrollPanePayment.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
                      scrollPanePayment.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
                      scrollPanePayment.setBounds(23, 11, 325, 215);
                      panelforPaymentPart.add(scrollPanePayment);
                      
                   // Assuming tablePayment is your target table
                      JTable tablePayment = new JTable();
                      tablePayment.setModel(new DefaultTableModel(
                          new Object[][] {},
                          new String[] { "Purchase", "Price" }
                      ));
                      scrollPanePayment.setViewportView(tablePayment);

                      // ...
                      
                      JTextArea textAreaPayment = new JTextArea();
                      textAreaPayment.setBackground(new Color(95, 158, 160));
                      textAreaPayment.setBounds(23, 223, 325, 34);
                      panelforPaymentPart.add(textAreaPayment);
                      
                      JPanel panelForCustomerInfo = new JPanel();
                      panelForCustomerInfo.setBorder(new TitledBorder(null, "Customer Information", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(255, 255, 255)));
                      panelForCustomerInfo.setLayout(null);
                      panelForCustomerInfo.setBackground(new Color(95, 158, 160));
                      panelForCustomerInfo.setBounds(434, 11, 335, 246);
                      panelforPaymentPart.add(panelForCustomerInfo);
                      
                      textFieldName = new JTextField();
                      textFieldName.setColumns(10);
                      textFieldName.setBounds(105, 22, 220, 20);
                      panelForCustomerInfo.add(textFieldName);
                      
                      textFieldAddress = new JTextField();
                      textFieldAddress.setColumns(10);
                      textFieldAddress.setBounds(105, 53, 220, 20);
                      panelForCustomerInfo.add(textFieldAddress);
                      
                      textFieldContact = new JTextField();
                      textFieldContact.setColumns(10);
                      textFieldContact.setBounds(105, 84, 220, 20);
                      panelForCustomerInfo.add(textFieldContact);
                      
                      JLabel lblNamePayment = new JLabel("Name:");
                      lblNamePayment.setFont(new Font("Georgia", Font.PLAIN, 11));
                      lblNamePayment.setBounds(10, 25, 85, 14);
                      panelForCustomerInfo.add(lblNamePayment);
                      
                      JLabel lblAddressPayment = new JLabel("Address:");
                      lblAddressPayment.setFont(new Font("Georgia", Font.PLAIN, 11));
                      lblAddressPayment.setBounds(10, 56, 85, 14);
                      panelForCustomerInfo.add(lblAddressPayment);
                      
                      JLabel lblContactPayment = new JLabel("Contact:");
                      lblContactPayment.setFont(new Font("Georgia", Font.PLAIN, 11));
                      lblContactPayment.setBounds(10, 87, 85, 14);
                      panelForCustomerInfo.add(lblContactPayment);
                      
                      JLabel lblEmailPayment = new JLabel("Email:");
                      lblEmailPayment.setFont(new Font("Georgia", Font.PLAIN, 11));
                      lblEmailPayment.setBounds(10, 118, 85, 14);
                      panelForCustomerInfo.add(lblEmailPayment);
                      
                      textFieldEmail = new JTextField();
                      textFieldEmail.setColumns(10);
                      textFieldEmail.setBounds(105, 115, 220, 20);
                      panelForCustomerInfo.add(textFieldEmail);
                      
                      JButton btnOK = new JButton("OK");
                      btnOK.setFont(new Font("Georgia", Font.BOLD, 15));
                      btnOK.setBounds(0, 213, 335, 33);
                      panelForCustomerInfo.add(btnOK);
                      
                      JButton btnEditCustomerInfo = new JButton("Edit");
                      btnEditCustomerInfo.setBackground(new Color(255, 255, 255));
                      btnEditCustomerInfo.setFont(new Font("Georgia", Font.PLAIN, 11));
                      btnEditCustomerInfo.setBounds(236, 140, 89, 23);
                      panelForCustomerInfo.add(btnEditCustomerInfo);
                      
                      JPanel panelReciept = new JPanel();
                      panelReciept.setLayout(null);
                      panelReciept.setBorder(new TitledBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Receipt", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(95, 158, 160)), "Reciept ", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 128, 128)));
                      panelReciept.setBounds(837, 11, 335, 246);
                      panelforPaymentPart.add(panelReciept);
                   

        Product = new JPanel();
        Product.setBackground(new Color(0, 128, 128));
        Product.setBorder(new LineBorder(new Color(0, 128, 128), 2));
        Product.setBounds(0, 0, 1227, 300);
        MainPanel2.add(Product);
        Product.setLayout(null);

        addEditablePanelGrid(Product);
        
        JPanel panel_3 = new JPanel();
        panel_3.setBackground(new Color(0, 128, 128));
        panel_3.setBounds(0, 397, 1217, 39);
        Product.add(panel_3);
        panel_3.setLayout(null);
        
        JButton btnGotoCart = new JButton("Go to Cart");
        btnGotoCart.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		showPanel(Cart);
        	}
        });
        
        JLabel lblNewLabel = new JLabel("Happy Shopping");
        lblNewLabel.setFont(new Font("Georgia", Font.BOLD, 20));
        lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
        lblNewLabel.setBounds(10, -1, 224, 39);
        panel_3.add(lblNewLabel);
        btnGotoCart.setBackground(new Color(192, 192, 192));
        btnGotoCart.setFont(new Font("Sitka Text", Font.BOLD, 15));
        btnGotoCart.setBounds(1008, 9, 181, 28);
        panel_3.add(btnGotoCart);
       

       
        Account2 = new JPanel();
        Account2.setBorder(new LineBorder(new Color(0, 128, 128), 5));
        Account2.setBackground(new Color(0, 128, 128));
        Account2.setBounds(29, 240, 1226, 447);       
        MainPanel2.add(Account2);       
        Account2.setLayout(null);
        
        JPanel panel_4 = new JPanel();
        panel_4.setBounds(164, 0, 1053, 436);
        Account2.add(panel_4);
        panel_4.setLayout(null);
        
        JPanel panel_9 = new JPanel();
        panel_9.setBackground(new Color(192, 192, 192));
        panel_9.setBounds(10, 11, 1033, 414);
        panel_4.add(panel_9);
        panel_9.setLayout(null);
                
        
        JPanel panel_11 = new JPanel();
        panel_11.setBackground(new Color(192, 192, 192));
        panel_11.setBounds(42, 30, 534, 118);
        panel_9.add(panel_11);
        panel_11.setLayout(null);
        
        JLabel lblNewLabel_1_2 = new JLabel("Address:");
        lblNewLabel_1_2.setFont(new Font("Georgia", Font.PLAIN, 11));
        lblNewLabel_1_2.setBounds(10, 86, 68, 14);
        panel_11.add(lblNewLabel_1_2);
        
        JLabel lblNewLabel_1_1_1 = new JLabel("Email:");
        lblNewLabel_1_1_1.setFont(new Font("Georgia", Font.PLAIN, 11));
        lblNewLabel_1_1_1.setBounds(10, 61, 68, 14);
        panel_11.add(lblNewLabel_1_1_1);
        
        JLabel lblNewLabel_1_1 = new JLabel("Contact:");
        lblNewLabel_1_1.setFont(new Font("Georgia", Font.PLAIN, 11));
        lblNewLabel_1_1.setBounds(10, 36, 68, 14);
        panel_11.add(lblNewLabel_1_1);
        
        JLabel lblNewLabel_1 = new JLabel("Name:");
        lblNewLabel_1.setFont(new Font("Georgia", Font.PLAIN, 11));
        lblNewLabel_1.setBounds(10, 11, 68, 14);
        panel_11.add(lblNewLabel_1);
        
        textField = new JTextField();
        textField.setFont(new Font("Georgia", Font.PLAIN, 11));
        textField.setHorizontalAlignment(SwingConstants.LEFT);
        textField.setForeground(new Color(0, 0, 0));
        textField.setBackground(new Color(0, 128, 128));
        textField.setBounds(131, 8, 393, 20);
        panel_11.add(textField);
        textField.setColumns(10);
        
        textField_1 = new JTextField();
        textField_1.setFont(new Font("Georgia", Font.PLAIN, 11));
        textField_1.setHorizontalAlignment(SwingConstants.LEFT);
        textField_1.setBackground(new Color(0, 128, 128));
        textField_1.setBounds(131, 33, 393, 20);
        panel_11.add(textField_1);
        textField_1.setColumns(10);
        
        textField_2 = new JTextField();
        textField_2.setFont(new Font("Georgia", Font.PLAIN, 11));
        textField_2.setHorizontalAlignment(SwingConstants.LEFT);
        textField_2.setBackground(new Color(0, 128, 128));
        textField_2.setBounds(131, 58, 393, 20);
        panel_11.add(textField_2);
        textField_2.setColumns(10);
        
        textField_3 = new JTextField();
        textField_3.setFont(new Font("Georgia", Font.PLAIN, 11));
        textField_3.setHorizontalAlignment(SwingConstants.LEFT);
        textField_3.setBackground(new Color(0, 128, 128));
        textField_3.setBounds(131, 83, 393, 20);
        panel_11.add(textField_3);
        textField_3.setColumns(10);
        
        JButton btnNewButton_2 = new JButton("Save");
        btnNewButton_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        	}
        });
        btnNewButton_2.setFont(new Font("Georgia", Font.PLAIN, 11));
        btnNewButton_2.setBounds(52, 159, 168, 23);
        panel_9.add(btnNewButton_2);
        
        JButton btnNewButton_2_1 = new JButton("Update");
        btnNewButton_2_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        	}
        });
        btnNewButton_2_1.setFont(new Font("Georgia", Font.PLAIN, 11));
        btnNewButton_2_1.setBounds(225, 159, 168, 23);
        panel_9.add(btnNewButton_2_1);
        
        JButton btnNewButton_2_2 = new JButton("Delete");
        btnNewButton_2_2.setBounds(398, 159, 168, 23);
        panel_9.add(btnNewButton_2_2);
        btnNewButton_2_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        	}
        });
        btnNewButton_2_2.setFont(new Font("Georgia", Font.PLAIN, 11));
        
        JScrollPane scrollPane_3 = new JScrollPane();
        scrollPane_3.setBounds(42, 193, 534, 76);
        panel_9.add(scrollPane_3);
        
        JPanel panel_12 = new JPanel();
        scrollPane_3.setColumnHeaderView(panel_12);
        panel_12.setLayout(null);
        
      //  table_3 = new JTable();
       // table_3.setModel(new DefaultTableModel(
        //	model=new DefaultTableModel();
        	//Object[] column ={"Name","Contact","Email","Address"};
        //	Object[] row = new Object [4];
        //	table.setModel(model);
    
        	
       
       // scrollPane_3.setViewportView(table_3);
        
        JPanel panel_7 = new JPanel();
        panel_7.setBackground(new Color(0, 0, 0));
        panel_7.setBounds(0, 0, 164, 157);
        Account2.add(panel_7);
        panel_7.setLayout(null);
        
        JLabel lblImageholder = new JLabel("");
        lblImageholder.setHorizontalAlignment(SwingConstants.CENTER);
        lblImageholder.setIcon(new ImageIcon("C:\\Users\\Administrator\\Downloads\\medium.png"));
        lblImageholder.setBounds(0, 0, 164, 157);
        panel_7.add(lblImageholder);
        
        JPanel panel_8 = new JPanel();
        panel_8.setBackground(new Color(128, 128, 128));
        panel_8.setBounds(0, 156, 164, 56);
        Account2.add(panel_8);
        panel_8.setLayout(null);
        
        JPanel panel_8_1 = new JPanel();
        panel_8_1.setBackground(new Color(192, 192, 192));
        panel_8_1.setBounds(0, 211, 164, 56);
        Account2.add(panel_8_1);
        panel_8_1.setLayout(null);
      

            OrderHistory = new JPanel();
            OrderHistory.setBackground(new Color(0, 128, 128));
            OrderHistory.setBorder(new LineBorder(new Color(0, 128, 128), 5));
            OrderHistory.setBounds(0, 0, 1227, 382);
            MainPanel2.add(OrderHistory);
            OrderHistory.setLayout(null);
            
            JPanel panel_2 = new JPanel();
            panel_2.setBounds(0, 0, 1217, 382);
            OrderHistory.add(panel_2);
            panel_2.setLayout(null);
            
            JScrollPane scrollPane_2 = new JScrollPane();
            scrollPane_2.setBounds(0, 0, 1217, 382);
            panel_2.add(scrollPane_2);
            
            table_2 = new JTable();
            table_2.setModel(new DefaultTableModel(
            	new Object[][] {
            	},
            	new String[] {
            		"New column", "New column", "New column", "New column", "New column"
            	}
            ));
            scrollPane_2.setViewportView(table_2);
            
        

         // Assuming Cart is your JPanel
            Cart = new JPanel();
            Cart.setBackground(new Color(0, 128, 128));
            Cart.setBorder(new LineBorder(new Color(0, 128, 128), 3));
            Cart.setBounds(0, 0, 1227, 382);
            MainPanel2.add(Cart);
            Cart.setLayout(null);
            
            JScrollPane scrollPane = new JScrollPane();
            scrollPane.setBorder(new LineBorder(new Color(0, 128, 128), 5));
            scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
            scrollPane.setBounds(186, 11, 1011, 395);
            Cart.add(scrollPane);
            
         // Your table initialization
            table = new JTable();
            table.setFont(new Font("Georgia", Font.PLAIN, 11));
            table.setModel(new DefaultTableModel(
                new Object[][] {},
                new String[] { "Product Name", "Selected Size", "Selected Quantity", "Total Price" }
            ));

            // Set the background color of the table header
            JTableHeader tableHeader = table.getTableHeader();
            tableHeader.setBackground(new Color(0, 128, 128)); // Set your desired color

            // Set the foreground (text) color of the table header
            tableHeader.setForeground(Color.WHITE); // Set your desired color

            // Add the table to the scroll pane
            scrollPane.setViewportView(table);
            
            JPanel panel_6 = new JPanel();
            panel_6.setBackground(new Color(0, 128, 128));
            panel_6.setBounds(0, 11, 189, 403);
            Cart.add(panel_6);
            panel_6.setLayout(null);
            
            
            // Delete Row Button
            JButton btnDeleteRow = new JButton("Delete Row");
            btnDeleteRow.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    int selectedRow = table.getSelectedRow();

                    if (selectedRow != -1) {
                        // Get the table model
                        DefaultTableModel model = (DefaultTableModel) table.getModel();

                        // Remove the selected row
                        model.removeRow(selectedRow);
                    } else {
                        // Inform the user that no row is selected
                        JOptionPane.showMessageDialog(null, "Please select a row to delete.", "No Row Selected", JOptionPane.WARNING_MESSAGE);
                    }
                }
            });
            btnDeleteRow.setFocusable(false);
            btnDeleteRow.setBorder(new LineBorder(new Color(192, 192, 192), 5));
            btnDeleteRow.setBackground(new Color(95, 158, 160));
            btnDeleteRow.setFont(new Font("Georgia", Font.PLAIN, 11));
            btnDeleteRow.setBounds(20, 7, 167, 71);
            panel_6.add(btnDeleteRow);
            
            
         // Clear All Button
            JButton btnClearAll = new JButton("Clear All");
            btnClearAll.setFocusable(false);
            btnClearAll.setBorder(new LineBorder(new Color(192, 192, 192), 5));
            btnClearAll.setBackground(new Color(95, 158, 160));
            btnClearAll.setFont(new Font("Georgia", Font.PLAIN, 11));
            btnClearAll.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    // Get the table model
                    DefaultTableModel model = (DefaultTableModel) table.getModel();

                    // Remove all rows
                    model.setRowCount(0);
                }
            });
            btnClearAll.setBounds(20, 77, 167, 71);
            panel_6.add(btnClearAll);
            
            
         // Add All The Total Price Button
            JButton btnAddAll = new JButton("Add All The Total Price");
            btnAddAll.setFocusable(false);
            btnAddAll.setBorder(new LineBorder(new Color(192, 192, 192), 5));
            btnAddAll.setBackground(new Color(95, 158, 160));
            btnAddAll.setFont(new Font("Georgia", Font.PLAIN, 11));
            btnAddAll.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    // Get the table model
                    DefaultTableModel model = (DefaultTableModel) table.getModel();

                    // Get the column index for the "Total Price" column
                    int totalColumnIndex = model.findColumn("Total Price");

                    // Get the total number of rows in the table
                    int rowCount = model.getRowCount();

                    // Variable to store the sum of total prices
                    double totalSum = 0.0;

                    // Loop through each row and add the total price to the sum
                    for (int i = 0; i < rowCount; i++) {
                        double totalPrice = (double) model.getValueAt(i, totalColumnIndex);
                        totalSum += totalPrice;
                    }

                    // Display the sum in the TextAreaAllTotal
                    TextAreaAllTotal.setText("Total: ₱" + String.format("%.2f", totalSum));
                }
            });
            btnAddAll.setBounds(20, 148, 167, 71);
            panel_6.add(btnAddAll);
            
            
         // Check Out Button
            JButton btnCheckOut = new JButton("Check Out");
            btnCheckOut.setFocusable(false);
            btnCheckOut.setBorder(new LineBorder(new Color(192, 192, 192), 5));
            btnCheckOut.setFont(new Font("Georgia", Font.PLAIN, 11));
            btnCheckOut.setBackground(new Color(95, 158, 160));
            btnCheckOut.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    // Get the table model for the source table (table)
                    DefaultTableModel sourceModel = (DefaultTableModel) table.getModel();

                    // Get the column indices for the columns you want to retrieve data from
                    int productNameColumnIndex = sourceModel.findColumn("Product Name");
                    int selectedSizeColumnIndex = sourceModel.findColumn("Selected Size");
                    int selectedQuantityColumnIndex = sourceModel.findColumn("Selected Quantity");
                    int totalPriceColumnIndex = sourceModel.findColumn("Total Price");

                    // Get the table model for the target table (tablePayment)
                    DefaultTableModel targetModel = (DefaultTableModel) tablePayment.getModel();

                    // Add columns to the target table if not already added
                    if (targetModel.getColumnCount() == 0) {
                        targetModel.addColumn("Purchase");
                        targetModel.addColumn("Price");
                    }

                    // Process each row in the source table
                    for (int i = 0; i < sourceModel.getRowCount(); i++) {
                        // Retrieve data from each column for the current row
                        String productName = (String) sourceModel.getValueAt(i, productNameColumnIndex);
                        String selectedSize = (String) sourceModel.getValueAt(i, selectedSizeColumnIndex);
                        int selectedQuantity = (int) sourceModel.getValueAt(i, selectedQuantityColumnIndex);
                        double totalPrice = (double) sourceModel.getValueAt(i, totalPriceColumnIndex);

                        // Construct the "Purchase" column value
                        String purchaseValue = productName + " - " + selectedSize + " - " + selectedQuantity;

                        // Add a new row to the target table with the gathered information
                        Object[] rowData = { purchaseValue, totalPrice };
                        targetModel.addRow(rowData);
                    }

                    // Optionally, you can clear the source table after processing
                    sourceModel.setRowCount(0);

                    // Update the total in the textAreaPayment
                    double totalSum = 0.0;
                    for (int i = 0; i < targetModel.getRowCount(); i++) {
                        totalSum += (double) targetModel.getValueAt(i, 1);
                    }
                    textAreaPayment.setText("Total: ₱" + String.format("%.2f", totalSum));
                    
                    
                     
                             showPanel(Payment);
                        
          
                }
                
            });
            btnCheckOut.setBounds(20, 319, 167, 71);
            panel_6.add(btnCheckOut);
            
            
            //TextAreaAllTotal
            TextAreaAllTotal = new JTextArea();
            TextAreaAllTotal.setEditable(false);
            TextAreaAllTotal.setFont(new Font("Tahoma", Font.PLAIN, 15));
            TextAreaAllTotal.setBorder(new LineBorder(new Color(192, 192, 192), 5));
            TextAreaAllTotal.setBackground(new Color(224, 255, 255));
            TextAreaAllTotal.setBounds(20, 219, 169, 102);
            panel_6.add(TextAreaAllTotal);
        }
            

	
	
            private void addEditablePanelGrid(JPanel parentPanel) {
            JPanel scrollPanelContentCart = new JPanel();
            scrollPanelContentCart.setBackground(new Color(192, 192, 192));
            scrollPanelContentCart.setBorder(null);
            JScrollPane scrollPaneCart = new JScrollPane(scrollPanelContentCart, ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
            scrollPaneCart.setViewportBorder(new LineBorder(new Color(128, 128, 128), 5));
            scrollPanelContentCart.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
            scrollPaneCart.setLocation(0, 0);
            scrollPaneCart.setSize(1217, 395);

            int labelWidth = 200;
            int labelHeight = 350;

            // Prices for each product and size
            String[] pricesPanel1 = {"300", "400", "500", "600", "700"};
            String[] pricesPanel2 = {"450", "500", "570", "800", "900"};
            String[] pricesPanel3 = {"300", "400", "500", "600", "700"};
            String[] pricesPanel4 = {"450", "500", "570", "800", "900"};
            String[] pricesPanel5 = {"300", "400", "500", "600", "700"};
            String[] pricesPanel6 = {"450", "500", "570", "800", "900"};
            String[] pricesPanel7 = {"300", "400", "500", "600", "700"};
            String[] pricesPanel8 = {"450", "500", "570", "800", "900"};
            String[] pricesPanel9 = {"300", "400", "500", "600", "700"};
            String[] pricesPanel10 = {"450", "500", "570", "800", "900"};
            String[] pricesPanel11 = {"300", "400", "500", "600", "700"};
            String[] pricesPanel12 = {"450", "500", "570", "800", "900"};

            // Panel 1
            JPanel panel1 = createEditablePanel("Era", pricesPanel1, "AA.jpg");
            panel1.setPreferredSize(new Dimension(labelWidth, labelHeight));
            scrollPanelContentCart.add(panel1);

            // Panel 2
            JPanel panel2 = createEditablePanel("Happy", pricesPanel2, "imghello");
            panel2.setPreferredSize(new Dimension(labelWidth, labelHeight));
            scrollPanelContentCart.add(panel2);

            JPanel panel3 = createEditablePanel("Hakdog", pricesPanel3, "imgdog");
            panel3.setPreferredSize(new Dimension(labelWidth, labelHeight));
            scrollPanelContentCart.add(panel3);

            JPanel panel4 = createEditablePanel("Mike", pricesPanel4, "imgmike");
            panel4.setPreferredSize(new Dimension(labelWidth, labelHeight));
            scrollPanelContentCart.add(panel4);

            JPanel panel5 = createEditablePanel("CJ", pricesPanel5, "AA.jpg");
            panel5.setPreferredSize(new Dimension(labelWidth, labelHeight));
            scrollPanelContentCart.add(panel5);

            JPanel panel6 = createEditablePanel("Joshua", pricesPanel6, "AA.jpg");
            panel6.setPreferredSize(new Dimension(labelWidth, labelHeight));
            scrollPanelContentCart.add(panel6);

            JPanel panel7 = createEditablePanel("Mae", pricesPanel7, "AA.jpg");
            panel7.setPreferredSize(new Dimension(labelWidth, labelHeight));
            scrollPanelContentCart.add(panel7);

            JPanel panel8 = createEditablePanel("Jerald", pricesPanel8, "AA.jpg");
            panel8.setPreferredSize(new Dimension(labelWidth, labelHeight));
            scrollPanelContentCart.add(panel8);

            JPanel panel9 = createEditablePanel("Christian", pricesPanel9, "AA.jpg");
            panel9.setPreferredSize(new Dimension(labelWidth, labelHeight));
            scrollPanelContentCart.add(panel9);

            JPanel panel10 = createEditablePanel("HAHAHAH", pricesPanel10, "AA.jpg");
            panel10.setPreferredSize(new Dimension(labelWidth, labelHeight));
            scrollPanelContentCart.add(panel10);

            JPanel panel11 = createEditablePanel("example", pricesPanel11, "AA.jpg");
            panel11.setPreferredSize(new Dimension(labelWidth, labelHeight));
            scrollPanelContentCart.add(panel11);

            JPanel panel12 = createEditablePanel("ok", pricesPanel12, "AA.jpg");
            panel12.setPreferredSize(new Dimension(labelWidth, labelHeight));
            scrollPanelContentCart.add(panel12);

            parentPanel.setLayout(null);
            parentPanel.add(scrollPaneCart);
            }

            private JPanel createEditablePanel(String initialTitle, String[] prices, String imagePath) {
                JPanel panel = new JPanel();
                panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
                panel.setBorder(new LineBorder(new Color(0, 128, 128), 6));
                panel.setOpaque(true);

             // Editable title
                JTextField titleField = new JTextField(initialTitle);
                titleField.setBackground(new Color(95, 158, 160));
                titleField.setFont(new Font("Georgia", Font.PLAIN, 11));
                titleField.setMaximumSize(new Dimension(500, 20));
                titleField.setEditable(false);
                panel.add(titleField);

                
             // Image Panel with JLabel
                JPanel imagePanel = new JPanel();
                imagePanel.setBorder(new LineBorder(new Color(0, 128, 128), 5, true));
                imagePanel.setPreferredSize(new Dimension(200, 300));
                

                // Load the image from the specified file path
                try {
                    // Assuming imagePath is a valid path to the image file
                    ImageIcon imageIcon = new ImageIcon(imagePath);
                    Image image = imageIcon.getImage().getScaledInstance(200, 300, Image.SCALE_SMOOTH);
                    imageIcon = new ImageIcon(image);

                    // Create a JLabel to hold the image
                    JLabel imageLabel = new JLabel(new ImageIcon("C:\\Users\\Mike\\Downloads\\.jpg"));
                    Image resizedImage = ((Image) imageLabel.getIcon()).getScaledInstance(300, 200, Image.SCALE_SMOOTH);
                    ImageIcon resizedIcon = new ImageIcon(resizedImage);
                    // Add the image label to the image panel
                    imagePanel.add(imageLabel);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                // Add the image panel to the main panel
                panel.add(imagePanel);

                // Editable PricePanel
                JPanel pricePanel = new JPanel();
                pricePanel.setBackground(new Color(255, 255, 255));
                pricePanel.setLayout(new FlowLayout(FlowLayout.LEFT));
                JLabel priceLabel = new JLabel("₱" + prices[0]);
                priceLabel.setPreferredSize(new Dimension(150, 20));
                pricePanel.add(priceLabel);

                panel.add(pricePanel);

                // Quantity part--------------------------------------------------------------------------------
                JPanel quantityAndSizePanel = new JPanel();
                quantityAndSizePanel.setBackground(new Color(255, 255, 255));
                quantityAndSizePanel.setLayout(new BoxLayout(quantityAndSizePanel, BoxLayout.X_AXIS));

                quantityAndSizePanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(0, 128, 128), 5), "Quantity and Size"));

                JPanel quantityPanel = new JPanel();
                quantityPanel.setLayout(new BoxLayout(quantityPanel, BoxLayout.X_AXIS));

                JTextField quantityField = new JTextField("1", 3);
                quantityField.setEditable(false);
                quantityField.setHorizontalAlignment(JTextField.CENTER);

                JButton plusButton = new JButton("+");
                plusButton.setFocusable(false);
                JButton minusButton = new JButton("-");
                minusButton.setFocusable(false);

                plusButton.addActionListener(e -> {
                    int currentQuantity = Integer.parseInt(quantityField.getText());
                    quantityField.setText(String.valueOf(currentQuantity + 1));
                });

                minusButton.addActionListener(e -> {
                    int currentQuantity = Integer.parseInt(quantityField.getText());
                    if (currentQuantity > 1) {
                        quantityField.setText(String.valueOf(currentQuantity - 1));
                    }
                });

                quantityPanel.add(minusButton);
                quantityPanel.add(quantityField);
                quantityPanel.add(plusButton);

                quantityAndSizePanel.add(quantityPanel);

                // Combo box size selection part-----------------------------------------------------------------------
                String[] sizes = {"XS", "Small", "Medium", "Large", "XL"};
                JComboBox<String> sizeComboBox = new JComboBox<>(sizes);
                sizeComboBox.setFont(new Font("Arial", Font.BOLD, 11));
                sizeComboBox.setFocusable(false);

                // Set the initial price
                sizeComboBox.addActionListener(e -> {
                    int selectedIndex = sizeComboBox.getSelectedIndex();
                    priceLabel.setText("₱" + prices[selectedIndex]);

                    // Update total price based on the selected quantity
                    updateTotalPrice(prices, quantityField, sizeComboBox, priceLabel);
                });

                sizeComboBox.setMaximumSize(new Dimension(90, 30));
                quantityAndSizePanel.add(sizeComboBox);

                quantityAndSizePanel.add(quantityPanel);

                panel.add(quantityAndSizePanel);

             // Add to Cart Part
                JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
                buttonPanel.setBackground(new Color(255, 255, 255));
                JButton addButton = new JButton("Add to Cart");
                addButton.setBackground(new Color(95, 158, 160));
                addButton.setFont(new Font("Century Gothic", Font.BOLD, 15));
                addButton.setFocusable(false);

                addButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        // Create a dialog to gather additional information
                        JPanel dialogPanel = new JPanel();
                        dialogPanel.setLayout(new BoxLayout(dialogPanel, BoxLayout.Y_AXIS));

                        // Product name
                        JLabel nameLabel = new JLabel("Product: " + initialTitle);
                        dialogPanel.add(nameLabel);

                        // Price
                        JLabel priceLabel = new JLabel("Price: ₱" + prices[0]);
                        dialogPanel.add(priceLabel);

                        // Size
                        JLabel sizeLabel = new JLabel("Size: " + sizes[sizeComboBox.getSelectedIndex()]);
                        dialogPanel.add(sizeLabel);

                        // Quantity
                        int selectedQuantity = Integer.parseInt(quantityField.getText());
                        JLabel quantityLabel = new JLabel("Quantity: " + selectedQuantity);
                        dialogPanel.add(quantityLabel);

                        // Text area for displaying total
                        JTextArea totalTextArea = new JTextArea();
                        totalTextArea.setEditable(false);
                        dialogPanel.add(new JLabel("Total:"));
                        dialogPanel.add(totalTextArea);

                        // Update total when quantity changes
                        totalTextArea.setText("₱" + (selectedQuantity * Double.parseDouble(prices[sizeComboBox.getSelectedIndex()])));

                        int result = JOptionPane.showConfirmDialog(null, dialogPanel, "Add to Cart", JOptionPane.OK_CANCEL_OPTION);

                        // If the user clicks OK, add the item to the cart
                        if (result == JOptionPane.OK_OPTION) {
                            String productName = initialTitle;
                            String selectedSize = sizes[sizeComboBox.getSelectedIndex()];
                            int selectedPrice = Integer.parseInt(prices[sizeComboBox.getSelectedIndex()]);
                            double totalPrice = selectedQuantity * selectedPrice;

                            // Use the method to add the data to your table model
                            //addToCartTableModel1(productName, selectedSize, selectedPrice, selectedQuantity, totalPrice);
                            addToCartTableModel(productName, selectedSize, selectedPrice, selectedQuantity, totalPrice);
                            // Now you can do something with the gathered information,
                            // such as adding it to a shopping cart or displaying it somewhere.
                            System.out.println("Product Name: " + productName);
                            System.out.println("Size: " + selectedSize);
                            System.out.println("Quantity: " + selectedQuantity);
                            System.out.println("Total Price: ₱" + totalPrice);
                        }
                    }
                });

                addButton.setPreferredSize(new Dimension(250, 50));
                addButton.setBorder(BorderFactory.createLineBorder(new Color(0, 128, 128), 5));
                buttonPanel.add(addButton);

                panel.add(buttonPanel);
                return panel;
          }
                protected void addToCartTableModel(String productName, String selectedSize, int selectedPrice,
                        int selectedQuantity, double totalPrice) {
                    DefaultTableModel model = (DefaultTableModel) table.getModel();

                    // Check if the product is already in the cart
                    for (int i = 0; i < model.getRowCount(); i++) {
                    	
                    	
                    	
                        String existingProduct = (String) model.getValueAt(i, 0);
                        String existingSize = (String) model.getValueAt(i, 1);

                        if (existingProduct.equals(productName) && existingSize.equals(selectedSize)) {
                            // Product is already in the cart, show a dialog
                            JOptionPane.showMessageDialog(null, "This product is already in your cart.", "Duplicate Product",
                                    JOptionPane.WARNING_MESSAGE);
                            return; // Do not add the duplicate product to the cart
                        }
                    }
                    

                    // If the product is not in the cart, add it to the table
                    model.addRow(new Object[]{productName, selectedSize, selectedQuantity, totalPrice});
                }

                private void updateTotalPrice(String[] prices, JTextField quantityField, JComboBox<String> sizeComboBox,
                        JLabel priceLabel) {
                    // TODO Auto-generated method stub
                }

	private void showPanel(JPanel panel) {
        Home.setVisible(panel == Home);
        Product.setVisible(panel == Product);
        Cart.setVisible(panel == Cart);
        OrderHistory.setVisible(panel == OrderHistory);
        Payment.setVisible(panel== Payment);
        Account2.setVisible(panel==Account2);
        
    }
}
