import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JLayeredPane;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

public class Dashboard {

	private JFrame frame;
	

    private  JButton btnNewButton;
    private  JButton btnProduct;
    private  JPanel Product;
    private  JPanel  Home;
    private  JPanel Cart;
    private  JPanel OrderHistory;
    private JTextField txtGhgghh;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;
    private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void In() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Dashboard window = new Dashboard();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Dashboard() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.setBounds(100, 100, 1292, 705);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		JPanel panel_4 = new JPanel();
		panel_4.setBorder(new LineBorder(new Color(0, 128, 128), 5, true));
		panel_4.setBackground(new Color(128, 128, 128));
		panel_4.setBounds(0, 0, 1276, 666);
		frame.getContentPane().add(panel_4);
		panel_4.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(27, 26, 1227, 109);
		panel_4.add(panel);
		panel.setBorder(new LineBorder(new Color(0, 128, 128), 5));
		panel.setBackground(new Color(192, 192, 192));
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(166, 35, 788, 48);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JButton btnNewButton_4 = new JButton("Search");
		btnNewButton_4.setFocusable(false);
		btnNewButton_4.setBackground(new Color(128, 128, 128));
		btnNewButton_4.setBounds(683, 11, 67, 23);
		panel_1.add(btnNewButton_4);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBackground(new Color(0, 128, 128));
		panel_5.setBounds(749, 11, 29, 23);
		panel_1.add(panel_5);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(955, 11, 81, 72);
		panel.add(lblNewLabel_1);
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\Administrator\\Downloads\\pingus-icon-icon.png"));
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(27, 185, 1227, 49);
		panel_4.add(panel_3);
		panel_3.setBorder(new LineBorder(new Color(0, 128, 128), 5));
		panel_3.setBackground(new Color(192, 192, 192));
		panel_3.setLayout(null);
		
		
		btnNewButton = new JButton("Home");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home.setVisible(true);
				Product.setVisible(false);
				Cart.setVisible(false);
				OrderHistory.setVisible(false);
			}
		});
		btnNewButton.setFont(new Font("Georgia", Font.PLAIN, 15));
		btnNewButton.setBounds(28, 11, 86, 27);
		panel_3.add(btnNewButton);
		
		 btnProduct = new JButton("Product");
		btnProduct.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home.setVisible(false);
				Product.setVisible(true);
				Cart.setVisible(false);
				OrderHistory.setVisible(false);
				
			}
		});
		btnProduct.setFont(new Font("Georgia", Font.PLAIN, 15));
		btnProduct.setBounds(135, 11, 86, 27);
		panel_3.add(btnProduct);
		
		JButton btnCart = new JButton("Cart");
		btnCart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home.setVisible(false);
				Product.setVisible(false);
				Cart.setVisible(true);
				OrderHistory.setVisible(false);
			}
		});
		btnCart.setFont(new Font("Georgia", Font.PLAIN, 15));
		btnCart.setBounds(242, 11, 86, 27);
		panel_3.add(btnCart);
		
		JButton btnOrderHistory = new JButton("Order History");
		btnOrderHistory.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home.setVisible(false);
				Product.setVisible(false);
				Cart.setVisible(false);
				OrderHistory.setVisible(true);
			}
		});
		btnOrderHistory.setFont(new Font("Georgia", Font.PLAIN, 15));
		btnOrderHistory.setBounds(354, 11, 140, 27);
		panel_3.add(btnOrderHistory);
		
		JLabel lblNewLabel = new JLabel("Hello Welcome");
		lblNewLabel.setFont(new Font("Georgia", Font.BOLD, 34));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(27, 136, 1227, 49);
		panel_4.add(lblNewLabel);
		
		JLayeredPane panel_2 = new JLayeredPane();
		panel_2.setBorder(new LineBorder(new Color(0, 128, 128), 5));
		panel_2.setBounds(27, 256, 1227, 382);
		panel_4.add(panel_2);
		panel_2.setLayout(null);
		 
		 Product = new JPanel();
		 Product.setBackground(new Color(188, 143, 143));
		 Product.setBorder(new LineBorder(new Color(0, 128, 128), 5));
		 Product.setBounds(0, 0, 1227, 382);
		 panel_2.add(Product);
		 Product.setLayout(null);
		 
		 JPanel panel_6 = new JPanel();
		 panel_6.setBounds(36, 37, 204, 204);
		 Product.add(panel_6);
		 panel_6.setLayout(null);
		 
		 JPanel panel_6_1 = new JPanel();
		 panel_6_1.setBounds(271, 37, 204, 204);
		 Product.add(panel_6_1);
		 panel_6_1.setLayout(null);
		 
		 JPanel panel_6_5 = new JPanel();
		 panel_6_5.setBounds(508, 37, 204, 204);
		 Product.add(panel_6_5);
		 panel_6_5.setLayout(null);
		 
		 JPanel panel_6_6 = new JPanel();
		 panel_6_6.setBounds(746, 37, 204, 204);
		 Product.add(panel_6_6);
		 panel_6_6.setLayout(null);
		 
		 JPanel panel_6_7 = new JPanel();
		 panel_6_7.setBounds(987, 37, 204, 204);
		 Product.add(panel_6_7);
		 panel_6_7.setLayout(null);
		 
		 txtGhgghh = new JTextField();
		 txtGhgghh.setBounds(36, 252, 204, 20);
		 txtGhgghh.setFont(new Font("Georgia", Font.PLAIN, 11));
		 txtGhgghh.setHorizontalAlignment(SwingConstants.CENTER);
		 txtGhgghh.setEditable(false);
		 Product.add(txtGhgghh);
		 txtGhgghh.setColumns(10);
		 
		 textField = new JTextField();
		 textField.setBounds(271, 252, 204, 20);
		 textField.setHorizontalAlignment(SwingConstants.CENTER);
		 textField.setFont(new Font("Georgia", Font.PLAIN, 11));
		 textField.setEditable(false);
		 textField.setColumns(10);
		 Product.add(textField);
		 
		 textField_1 = new JTextField();
		 textField_1.setBounds(508, 252, 204, 20);
		 textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		 textField_1.setFont(new Font("Georgia", Font.PLAIN, 11));
		 textField_1.setEditable(false);
		 textField_1.setColumns(10);
		 Product.add(textField_1);
		 
		 textField_2 = new JTextField();
		 textField_2.setBounds(746, 252, 204, 20);
		 textField_2.setHorizontalAlignment(SwingConstants.CENTER);
		 textField_2.setFont(new Font("Georgia", Font.PLAIN, 11));
		 textField_2.setEditable(false);
		 textField_2.setColumns(10);
		 Product.add(textField_2);
		 
		 textField_3 = new JTextField();
		 textField_3.setBounds(987, 252, 204, 20);
		 textField_3.setHorizontalAlignment(SwingConstants.CENTER);
		 textField_3.setFont(new Font("Georgia", Font.PLAIN, 11));
		 textField_3.setEditable(false);
		 textField_3.setColumns(10);
		 Product.add(textField_3);
		 
		 JScrollPane scrollPane = new JScrollPane();
		 scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		 scrollPane.setBounds(0, 0, 1227, 382);
		 Product.add(scrollPane);
		 
		 Cart = new JPanel();
		 Cart.setBackground(new Color(255, 182, 193));
		 Cart.setBorder(new LineBorder(new Color(0, 128, 128), 5));
		 Cart.setBounds(0, 0, 1227, 382);
		 panel_2.add(Cart);
		 Cart.setLayout(null);
		 
		 JPanel panel_6_2 = new JPanel();
		 panel_6_2.setBounds(521, 59, 171, 158);
		 Cart.add(panel_6_2);
		 
		 JPanel panel_6_3 = new JPanel();
		 panel_6_3.setBounds(761, 59, 171, 158);
		 Cart.add(panel_6_3);
		 
		 JPanel panel_6_4 = new JPanel();
		 panel_6_4.setBounds(993, 59, 171, 158);
		 Cart.add(panel_6_4);
		 
		 OrderHistory = new JPanel();
		 OrderHistory.setBackground(new Color(0, 128, 128));
		 OrderHistory.setBorder(new LineBorder(new Color(0, 128, 128), 5));
		 OrderHistory.setBounds(0, 0, 1227, 382);
		 panel_2.add(OrderHistory);
		 OrderHistory.setLayout(null);
		 
		 JLabel lblNewLabel_5 = new JLabel("Order History");
		 lblNewLabel_5.setBounds(86, 162, 207, 80);
		 OrderHistory.add(lblNewLabel_5);
		
		 Home = new JPanel();
		 Home.setBackground(new Color(0, 255, 255));
		 Home.setBorder(new LineBorder(new Color(0, 128, 128), 5));
		Home.setBounds(0, 0, 1227, 382);
		panel_2.add(Home);
		Home.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("Home");
		lblNewLabel_3.setBounds(235, 153, 46, 14);
		Home.add(lblNewLabel_3);
	}
}
