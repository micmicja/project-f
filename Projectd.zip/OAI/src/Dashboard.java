
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import org.mariadb.jdbc.MariaDbConnection;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.border.LineBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;



import net.proteanit.sql.DbUtils;

public class Dashboard {
	private String url = "jdbc:mariadb://localhost:3306/pos";
	private String user = "root";
	private String password = "";
	private JFrame frame;
	private JButton btnHome;
	private JButton btnCart;
	private JButton btnProduct;
	private JButton btnPayment;
	private JPanel Product;
	private JPanel Home;
	private JPanel Cart;
	private JPanel OrderHistory;
	// private JPanel Account1;
	private JTable table;
	private DefaultTableModel cartTableModel;
	
	int integer;
	// private JTable tableItems;
	// private int selectedIndex;
	// private AbstractButton textAreaofTotal;
	// private JTable table_1;
	// private JTable CartTable;
	private JTable table_2;
	private JPanel Account2;
	private JTextField name;
	private JTextField contactn;
	private JTextField address;
	private JTable PaymentTable;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField userName;
	private JPasswordField passWord;

	private void table_load1() {

		try (Connection connect = (Connection) DriverManager.getConnection(url, user, password)) {
			String query = "SELECT cartId as `#`, product.productId as `SKU`, name as `Product Name`, brand as `Brand`, cart.quantity as `Quantity`, size as 'Size', cart.price as `Total Price` FROM cart INNER JOIN product ON  cart.productId = product.productId WHERE userId ="
					+ GlobalVariables.userId;
			;
			try (PreparedStatement pst = connect.prepareStatement(query);

					ResultSet rs = pst.executeQuery()) {

				// Assuming 'table' is a JTable
				table.setModel(DbUtils.resultSetToTableModel(rs));

			} // Resources are closed automatically here

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void table_load2() {

		try (Connection connect = (Connection) DriverManager.getConnection(url, user, password)) {
			String query = "SELECT purchaseId as `#`, product.productId as `SKU`, name as `Product Name`, brand as `Brand`, purchase.quantity as `Quantity`, size as 'Size', purchase.price as `Total Price`, date as `Date` FROM purchase INNER JOIN product ON  purchase.productId = product.productId WHERE userId ="
					+ GlobalVariables.userId;
			
			;
			try (PreparedStatement pst = connect.prepareStatement(query);

					ResultSet rs = pst.executeQuery()) {

				// Assuming 'table' is a JTable
				table_2.setModel(DbUtils.resultSetToTableModel(rs));

			} // Resources are closed automatically here

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void deleteItemFromDatabase(int productNumber) {
		// Replace the following with your actual database connection details
		String url = "jdbc:mariadb://localhost:3306/pos";
		String user = "root";
		String password = "";

		try (Connection connection = (Connection) DriverManager.getConnection(url, user, password)) {
			// Replace "your_table_name" with the actual name of your "purchase" table
			String deleteQuery = "DELETE FROM purchase WHERE pid = ?";
			try (PreparedStatement deleteStatement = connection.prepareStatement(deleteQuery)) {
				deleteStatement.setInt(1, productNumber);
				deleteStatement.executeUpdate();
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	public static void In() {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					Dashboard window = new Dashboard();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Dashboard() {
		initialize();
		cartTableModel = new DefaultTableModel(
				new String[] { "#", "Product", "Size", "Price", "Quantity", "Total", "Select", "Remove" }, 0);
		table_load1();
		table_load2();
	}

	// @SuppressWarnings("removal")
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.setBounds(100, 100, 1292, 750);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		frame.setLocationRelativeTo(null);

		// The panel
		// Background-----------------------------------------------------------
		JPanel MainPanel = new JPanel();
		MainPanel.setBorder(new LineBorder(new Color(0, 128, 128), 5, true));
		MainPanel.setBackground(new Color(255, 255, 255));
		MainPanel.setBounds(0, 0, 1276, 711);
		frame.getContentPane().add(MainPanel);
		MainPanel.setLayout(null);

		// The Header
		// Part-----------------------------------------------------------------
		JPanel pnlHeader = new JPanel();
		pnlHeader.setBounds(27, 26, 1227, 95);
		MainPanel.add(pnlHeader);
		pnlHeader.setBorder(new LineBorder(new Color(0, 128, 128), 5));
		pnlHeader.setBackground(new Color(192, 192, 192));
		pnlHeader.setLayout(null);

		JPanel pnlSearch = new JPanel();
		pnlSearch.setBounds(141, 24, 887, 49);
		pnlHeader.add(pnlSearch);
		pnlSearch.setLayout(null);

		JLabel lblNewLabel_2 = new JLabel("CLOTHING PARADISE");
		lblNewLabel_2.setFont(new Font("Georgia", Font.PLAIN, 25));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(0, 12, 887, 26);
		pnlSearch.add(lblNewLabel_2);

		JButton btnLogout = new JButton("Logout");
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				OAI window = new OAI();
				window.frame.setVisible(true);

			}

		});

		btnLogout.setFont(new Font("Georgia", Font.PLAIN, 15));
		btnLogout.setFocusable(false);
		btnLogout.setBorder(new LineBorder(new Color(0, 128, 128), 5));
		btnLogout.setBackground(Color.GRAY);
		btnLogout.setBounds(1110, 35, 86, 27);
		pnlHeader.add(btnLogout);

		// The Part where the buttons of Home , Product, Cart, and Order
		// History-----------------------------------------------
		JPanel pblHPCOButton = new JPanel();
		pblHPCOButton.setBounds(27, 170, 1227, 49);
		MainPanel.add(pblHPCOButton);
		pblHPCOButton.setBorder(new LineBorder(new Color(0, 128, 128), 5));
		pblHPCOButton.setBackground(new Color(192, 192, 192));
		pblHPCOButton.setLayout(null);

		// Buttons----------------------------------------------------------------

		btnHome = new JButton("Home");
		btnHome.setBackground(new Color(128, 128, 128));
		btnHome.setBorder(new LineBorder(new Color(0, 128, 128), 5));
		btnHome.setFocusable(false);
		btnHome.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				showPanel(Home);
			}
		});
		btnHome.setFont(new Font("Georgia", Font.PLAIN, 15));
		btnHome.setBounds(28, 11, 86, 27);
		pblHPCOButton.add(btnHome);

		btnProduct = new JButton("Product");
		btnProduct.setBackground(new Color(128, 128, 128));
		btnProduct.setBorder(new LineBorder(new Color(0, 128, 128), 5));
		btnProduct.setFocusable(false);
		btnProduct.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				showPanel(Product);
			}
		});
		btnProduct.setFont(new Font("Georgia", Font.PLAIN, 15));
		btnProduct.setBounds(137, 11, 86, 27);
		pblHPCOButton.add(btnProduct);

		btnCart = new JButton("Cart");
		btnCart.setBackground(new Color(128, 128, 128));
		btnCart.setBorder(new LineBorder(new Color(0, 128, 128), 5));
		btnCart.setFocusable(false);
		btnCart.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				showPanel(Cart);

			}
		});
		btnCart.setFont(new Font("Georgia", Font.PLAIN, 15));
		btnCart.setBounds(246, 11, 86, 27);
		pblHPCOButton.add(btnCart);

		btnPayment = new JButton("Order History");
		btnPayment.setBackground(new Color(128, 128, 128));
		btnPayment.setBorder(new LineBorder(new Color(0, 128, 128), 5));
		btnPayment.setFocusable(false);
		btnPayment.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				showPanel(OrderHistory);
			}
		});
		btnPayment.setFont(new Font("Georgia", Font.PLAIN, 15));
		btnPayment.setBounds(356, 11, 140, 27);
		pblHPCOButton.add(btnPayment);

		JButton btnAccount2 = new JButton("Account");
		btnAccount2.setBounds(521, 11, 140, 27);
		pblHPCOButton.add(btnAccount2);
		btnAccount2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				showPanel(Account2);
			}
		});
		btnAccount2.setFont(new Font("Georgia", Font.PLAIN, 15));
		btnAccount2.setFocusable(false);
		btnAccount2.setBorder(new LineBorder(new Color(0, 128, 128), 5));
		btnAccount2.setBackground(new Color(128, 128, 128));

		// Hello Welcome
		// Part------------------------------------------------------------
		JLabel lblHelloWelcome = new JLabel("Hello Welcome");
		lblHelloWelcome.setFont(new Font("Georgia", Font.BOLD, 34));
		lblHelloWelcome.setHorizontalAlignment(SwingConstants.CENTER);
		lblHelloWelcome.setBounds(27, 123, 1227, 49);
		MainPanel.add(lblHelloWelcome);

		// The Part of Button
		// Panels-----------------------------------------------------
		JLayeredPane MainPanel2 = new JLayeredPane();
		MainPanel2.setBorder(new LineBorder(new Color(0, 128, 128), 5));
		MainPanel2.setBounds(27, 242, 1227, 446);
		MainPanel.add(MainPanel2);
		MainPanel2.setLayout(new CardLayout());

		// All The Codes in Home Panel--------------------------------------------------
		Home = new JPanel();
		Home.setBackground(new Color(0, 128, 128));
		Home.setBorder(new LineBorder(new Color(0, 128, 128), 5));
		Home.setBounds(0, 0, 1227, 382);
		MainPanel2.add(Home);
		Home.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(128, 128, 128), 5));
		panel.setBounds(173, 102, 844, 241);
		panel.setBackground(new Color(192, 192, 192));
		Home.add(panel);
		panel.setLayout(null);

		JPanel pnlWelcome = new JPanel();
		pnlWelcome.setBorder(null);
		pnlWelcome.setBounds(10, 11, 824, 100);
		panel.add(pnlWelcome);
		pnlWelcome.setLayout(null);

		JTextArea textAreaCustomerName = new JTextArea() {
			protected void paintComponent(Graphics g) {
				Graphics2D g2 = (Graphics2D) g.create();

				// Get the font metrics for the JTextArea's font
				FontMetrics fm = g2.getFontMetrics();

				// Calculate the x and y positions to center the text
				int x = (getWidth() - fm.stringWidth(getText())) / 2;
				int y = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();

				// Draw the text at the calculated position
				g2.drawString(getText(), x, y);

				// Dispose of the Graphics2D object to free up resources
				g2.dispose();
			}
		};
		textAreaCustomerName.setEnabled(false);
		textAreaCustomerName.setFont(new Font("Monospaced", Font.BOLD, 20));
		textAreaCustomerName.setBackground(new Color(255, 255, 255));
		textAreaCustomerName.setEditable(false);
		textAreaCustomerName.setText(GlobalVariables.username);
		textAreaCustomerName.setBounds(335, 77, 182, 22);
		textAreaCustomerName.setForeground(new Color(0, 128, 128));
		pnlWelcome.add(textAreaCustomerName);

		JLabel lblWelcome = new JLabel("WELCOME");
		lblWelcome.setBackground(new Color(0, 0, 0));
		lblWelcome.setHorizontalAlignment(SwingConstants.CENTER);
		lblWelcome.setForeground(new Color(0, 0, 0));
		lblWelcome.setFont(new Font("Georgia", Font.BOLD, 67));
		lblWelcome.setBounds(0, -3, 844, 102);
		pnlWelcome.add(lblWelcome);

		JPanel pnlInfo = new JPanel();
		pnlInfo.setBackground(new Color(192, 192, 192));
		pnlInfo.setBounds(290, 110, 281, 68);
		panel.add(pnlInfo);
		pnlInfo.setLayout(null);

		JLabel lblFirst = new JLabel(" Shop Name: Clothing Paradise \r\n");
		lblFirst.setFont(new Font("Times New Roman", Font.PLAIN, 11));
		lblFirst.setHorizontalAlignment(SwingConstants.CENTER);
		lblFirst.setBounds(0, 11, 281, 13);
		pnlInfo.add(lblFirst);

		JLabel lblSecond = new JLabel("Location: 123 Fashion Street, Cityville");
		lblSecond.setHorizontalAlignment(SwingConstants.CENTER);
		lblSecond.setFont(new Font("Times New Roman", Font.PLAIN, 11));
		lblSecond.setBounds(0, 29, 281, 13);
		pnlInfo.add(lblSecond);

		JLabel lblThird = new JLabel("Contact: +1 (123) 456-7890");
		lblThird.setFont(new Font("Times New Roman", Font.PLAIN, 11));
		lblThird.setHorizontalAlignment(SwingConstants.CENTER);
		lblThird.setBounds(0, 40, 281, 13);
		pnlInfo.add(lblThird);

		JPanel pnlAboutUs = new JPanel();
		pnlAboutUs.setBackground(new Color(192, 192, 192));
		pnlAboutUs.setBounds(81, 175, 665, 55);
		panel.add(pnlAboutUs);
		pnlAboutUs.setLayout(null);

		JLabel lbl1 = new JLabel("Clothing Paradise is your one-stop destination for the latest  fashion trends.    ");
		lbl1.setHorizontalAlignment(SwingConstants.CENTER);
		lbl1.setFont(new Font("Georgia", Font.BOLD, 15));
		lbl1.setBounds(0, 0, 665, 21);
		pnlAboutUs.add(lbl1);

		JLabel lbl2 = new JLabel("We offer a wide range of stylish and comfortable clothing for every occasion.");
		lbl2.setHorizontalAlignment(SwingConstants.CENTER);
		lbl2.setFont(new Font("Georgia", Font.BOLD, 15));
		lbl2.setBounds(0, 16, 665, 21);
		pnlAboutUs.add(lbl2);

		JLabel lbl3 = new JLabel("Shop with us and stay in style!     ");
		lbl3.setHorizontalAlignment(SwingConstants.CENTER);
		lbl3.setFont(new Font("Georgia", Font.BOLD, 15));
		lbl3.setBounds(0, 32, 665, 18);
		pnlAboutUs.add(lbl3);

		Product = new JPanel();
		Product.setBackground(new Color(0, 128, 128));
		Product.setBorder(new LineBorder(new Color(0, 128, 128), 2));
		Product.setBounds(0, 0, 1227, 300);
		MainPanel2.add(Product);
		Product.setLayout(null);

		addEditablePanelGrid(Product);

		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(0, 128, 128));
		panel_3.setBounds(0, 397, 1217, 39);
		Product.add(panel_3);
		panel_3.setLayout(null);

		JButton btnGotoCart = new JButton("Go to Cart");
		btnGotoCart.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				showPanel(Cart);
			}
		});

		JLabel lblNewLabel = new JLabel("Happy Shopping");
		lblNewLabel.setFont(new Font("Georgia", Font.BOLD, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setBounds(10, -1, 224, 39);
		panel_3.add(lblNewLabel);
		btnGotoCart.setBackground(new Color(192, 192, 192));
		btnGotoCart.setFont(new Font("Sitka Text", Font.BOLD, 15));
		btnGotoCart.setBounds(1008, 9, 181, 28);
		panel_3.add(btnGotoCart);

		Account2 = new JPanel();
		Account2.setBorder(new LineBorder(new Color(0, 128, 128), 5));
		Account2.setBackground(new Color(0, 128, 128));
		Account2.setBounds(29, 240, 1226, 447);
		MainPanel2.add(Account2);
		Account2.setLayout(null);

		JPanel panel_4 = new JPanel();
		panel_4.setBounds(164, 0, 1053, 436);
		Account2.add(panel_4);
		panel_4.setLayout(null);

		JPanel panel_9 = new JPanel();
		panel_9.setBackground(new Color(192, 192, 192));
		panel_9.setBounds(10, 11, 1033, 414);
		panel_4.add(panel_9);
		panel_9.setLayout(null);

		JPanel panel_11 = new JPanel();
		panel_11.setBackground(new Color(192, 192, 192));
		panel_11.setBounds(42, 30, 534, 152);
		panel_9.add(panel_11);
		panel_11.setLayout(null);

		JLabel lblNewLabel_1_2 = new JLabel("Address:");
		lblNewLabel_1_2.setFont(new Font("Georgia", Font.PLAIN, 11));
		lblNewLabel_1_2.setBounds(10, 62, 68, 14);
		panel_11.add(lblNewLabel_1_2);

		JLabel lblNewLabel_1_1_1 = new JLabel("Password");
		lblNewLabel_1_1_1.setFont(new Font("Georgia", Font.PLAIN, 11));
		lblNewLabel_1_1_1.setBounds(10, 118, 68, 14);
		panel_11.add(lblNewLabel_1_1_1);

		JLabel lblNewLabel_1_1 = new JLabel("Contact:");
		lblNewLabel_1_1.setFont(new Font("Georgia", Font.PLAIN, 11));
		lblNewLabel_1_1.setBounds(10, 36, 68, 14);
		panel_11.add(lblNewLabel_1_1);

		JLabel lblNewLabel_1 = new JLabel("Name:");
		lblNewLabel_1.setFont(new Font("Georgia", Font.PLAIN, 11));
		lblNewLabel_1.setBounds(10, 11, 68, 14);
		panel_11.add(lblNewLabel_1);

		name = new JTextField();
		name.setFont(new Font("Georgia", Font.PLAIN, 11));
		name.setHorizontalAlignment(SwingConstants.LEFT);
		name.setForeground(new Color(0, 0, 0));
		name.setBackground(new Color(0, 128, 128));
		String Name = GlobalVariables.name;
		name.setText(Name);
		name.setBounds(131, 8, 393, 20);
		panel_11.add(name);
		name.setColumns(10);

		contactn = new JTextField();
		contactn.setFont(new Font("Georgia", Font.PLAIN, 11));
		contactn.setHorizontalAlignment(SwingConstants.LEFT);
		contactn.setBackground(new Color(0, 128, 128));
		contactn.setBounds(131, 33, 393, 20);
		contactn.setText(GlobalVariables.phone);
		panel_11.add(contactn);
		contactn.setColumns(10);

		address = new JTextField();
		address.setFont(new Font("Georgia", Font.PLAIN, 11));
		address.setHorizontalAlignment(SwingConstants.LEFT);
		address.setBackground(new Color(0, 128, 128));
		address.setBounds(131, 59, 393, 20);
		address.setText(GlobalVariables.loaction);
		panel_11.add(address);
		address.setColumns(10);

		userName = new JTextField();
		userName.setHorizontalAlignment(SwingConstants.LEFT);
		userName.setFont(new Font("Georgia", Font.PLAIN, 11));
		userName.setColumns(10);
		userName.setBackground(new Color(0, 128, 128));
		userName.setText(GlobalVariables.username);
		userName.setBounds(131, 87, 393, 20);
		panel_11.add(userName);

		JLabel lblNewLabel_1_1_1_1 = new JLabel("Username:");
		lblNewLabel_1_1_1_1.setFont(new Font("Georgia", Font.PLAIN, 11));
		lblNewLabel_1_1_1_1.setBounds(10, 90, 68, 14);
		panel_11.add(lblNewLabel_1_1_1_1);
		
		passWord = new JPasswordField();
		passWord.setBackground(new Color(0, 128, 128));
		passWord.setBounds(131, 115, 393, 20);
		panel_11.add(passWord);
		passWord.setFont(new Font("Georgia", Font.PLAIN, 11));
		JButton btnNewButton_2_1 = new JButton("Update");
		btnNewButton_2_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if ( passWord.getText().isEmpty()
						) {
					JOptionPane.showMessageDialog(null, "Input Password","", JOptionPane.WARNING_MESSAGE);
					return; // Exit the method to prevent further execution
				}

				try (Connection connect = (Connection) DriverManager.getConnection(url, user, password)) {
					String sql = "UPDATE users SET name=?, location=?, phone=?, username=?, password=? WHERE id=?";

					try (PreparedStatement prepStat = connect.prepareStatement(sql)) {
						prepStat.setString(1, name.getText());
						prepStat.setString(2, address.getText());
						prepStat.setString(3, contactn.getText());
						prepStat.setString(4, userName.getText());
						prepStat.setString(5, passWord.getText());
						prepStat.setInt(6, GlobalVariables.userId);

						// Debugging: Print the SQL query
						System.out.println("SQL Query: " + prepStat.toString());

						int rowsAffected = prepStat.executeUpdate();

						// Handle the result or provide feedback as needed
						if (rowsAffected > 0) {
							JOptionPane.showMessageDialog(null, "Successfully Updated.", null,
									JOptionPane.INFORMATION_MESSAGE);
							
						} else {
							JOptionPane.showMessageDialog(null, "No rows were updated.", null,
									JOptionPane.INFORMATION_MESSAGE);
						}
					}
				} catch (SQLException ex) {
					ex.printStackTrace();
				}
			}

		});
		btnNewButton_2_1.setFont(new Font("Georgia", Font.PLAIN, 11));
		btnNewButton_2_1.setBounds(225, 193, 168, 23);
		panel_9.add(btnNewButton_2_1);

		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(42, 227, 534, 76);
		panel_9.add(scrollPane_3);

		JPanel panel_12 = new JPanel();
		scrollPane_3.setColumnHeaderView(panel_12);
		panel_12.setLayout(null);

		JPanel panel_7 = new JPanel();
		panel_7.setBackground(new Color(0, 0, 0));
		panel_7.setBounds(0, 0, 164, 157);
		Account2.add(panel_7);
		panel_7.setLayout(null);

		JLabel lblImageholder = new JLabel("");
		lblImageholder.setHorizontalAlignment(SwingConstants.CENTER);
		lblImageholder.setIcon(new ImageIcon("C:\\Users\\Administrator\\Downloads\\medium.png"));
		lblImageholder.setBounds(0, 0, 164, 157);
		panel_7.add(lblImageholder);

		JPanel panel_8 = new JPanel();
		panel_8.setBackground(new Color(128, 128, 128));
		panel_8.setBounds(0, 156, 164, 56);
		Account2.add(panel_8);
		panel_8.setLayout(null);

		JPanel panel_8_1 = new JPanel();
		panel_8_1.setBackground(new Color(192, 192, 192));
		panel_8_1.setBounds(0, 211, 164, 56);
		Account2.add(panel_8_1);
		panel_8_1.setLayout(null);

		OrderHistory = new JPanel();
		OrderHistory.setBackground(new Color(0, 128, 128));
		OrderHistory.setBorder(new LineBorder(new Color(0, 128, 128), 5));
		OrderHistory.setBounds(0, 0, 1227, 382);
		MainPanel2.add(OrderHistory);
		OrderHistory.setLayout(null);

		JPanel panel_2 = new JPanel();
		panel_2.setBounds(0, 0, 1217, 382);
		OrderHistory.add(panel_2);
		panel_2.setLayout(null);

		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(0, 0, 1217, 382);
		panel_2.add(scrollPane_2);

		table_2 = new JTable();
		table_2.setModel(new DefaultTableModel(new Object[][] {},
				new String[] { "New column", "New column", "New column", "New column", "New column" }));
		scrollPane_2.setViewportView(table_2);

		// Assuming Cart is your JPanel
		Cart = new JPanel();
		Cart.setBackground(new Color(0, 128, 128));
		Cart.setBorder(new LineBorder(new Color(0, 128, 128), 3));
		Cart.setBounds(0, 0, 1227, 382);
		MainPanel2.add(Cart);
		Cart.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBorder(new LineBorder(new Color(0, 128, 128), 5));
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(186, 11, 1011, 395);
		Cart.add(scrollPane);

		// Your table initialization
		table = new JTable();
		table.setFont(new Font("Georgia", Font.PLAIN, 11));
		table.setModel(new DefaultTableModel(new Object[][] {}, new String[] {

		}));

		// Set the background color of the table header
		JTableHeader tableHeader = table.getTableHeader();
		tableHeader.setBackground(new Color(0, 128, 128)); // Set your desired color

		// Set the foreground (text) color of the table header
		tableHeader.setForeground(Color.WHITE); // Set your desired color

		// Add the table to the scroll pane
		scrollPane.setViewportView(table);

		JPanel panel_6 = new JPanel();
		panel_6.setBackground(new Color(0, 128, 128));
		panel_6.setBounds(0, 11, 189, 403);
		Cart.add(panel_6);
		panel_6.setLayout(null);

		// Delete Row Button
		JButton btnDeleteRow = new JButton("Remove");
		btnDeleteRow.setVisible(false);
		btnDeleteRow.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int selectedRow = table.getSelectedRow();
				if (selectedRow != -1) {
					// Get the table model

					DefaultTableModel model = (DefaultTableModel) table.getModel();
					Vector<Object> rowData = (Vector<Object>) model.getDataVector().elementAt(selectedRow);
					// remove from database
					String url = "jdbc:mariadb://localhost:3306/pos";
					String user = "root";
					String password = "";

					try (Connection connection = (Connection) DriverManager.getConnection(url, user, password)) {
						// Replace "your_table_name" with the actual name of your "purchase" table
						String deleteQuery = "DELETE FROM cart WHERE cartId = ?";
						try (PreparedStatement deleteStatement = connection.prepareStatement(deleteQuery)) {
							deleteStatement.setString(1, rowData.get(0).toString());
							deleteStatement.executeUpdate();
						}
					} catch (SQLException ex) {
						ex.printStackTrace();
					}

					// Remove the selected row
					model.removeRow(selectedRow);

				} else {
					// Inform the user that no row is selected
					JOptionPane.showMessageDialog(null, "Please select a row to delete.", "No Row Selected",
							JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnDeleteRow.setFocusable(false);
		btnDeleteRow.setBorder(new LineBorder(new Color(192, 192, 192), 5));
		btnDeleteRow.setBackground(new Color(95, 158, 160));
		btnDeleteRow.setFont(new Font("Georgia", Font.PLAIN, 11));
		btnDeleteRow.setBounds(20, 7, 167, 71);
		panel_6.add(btnDeleteRow);

		// Check Out Button
		JButton btnCheckOut = new JButton("Check Out");
		btnCheckOut.setFocusable(false);
		btnCheckOut.setBorder(new LineBorder(new Color(192, 192, 192), 5));
		btnCheckOut.setFont(new Font("Georgia", Font.PLAIN, 11));
		btnCheckOut.setBackground(new Color(95, 158, 160));
		btnCheckOut.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				DefaultTableModel model = (DefaultTableModel) table.getModel();

				// String firstName = rowData.get(0).toString();
				int rowCount = model.getRowCount();

				double total = 0;

				for (int row = 0; row < rowCount; row++) {

					total += Double.parseDouble(model.getValueAt(row, 6).toString());

				}
				// System.out.println(total);
				// pop up confirm
				int confirmResult = JOptionPane.showConfirmDialog(null,
						"Are you sure you want to check out? " + " Total of " + total, "Confirm ",
						JOptionPane.YES_NO_OPTION);

				if (confirmResult == JOptionPane.YES_OPTION) {
					// remove from database

					List<List<Object>> toAdd = new ArrayList<>();

					for (int row = 0; row < rowCount; row++) {
						List<Object> rowList = new ArrayList<>();

						Object productId = model.getValueAt(row, 1);
						rowList.add(productId);
						Object quantity = model.getValueAt(row, 4);
						rowList.add(quantity);
						Object price = model.getValueAt(row, 6);
						rowList.add(price);
						Object sizeObj = model.getValueAt(row, 5);
					    String size = (sizeObj != null) ? sizeObj.toString() : "N/A";
						rowList.add(size);
						Object date = LocalDateTime.now();
						rowList.add(date);
						Object userId = GlobalVariables.userId;
						rowList.add(userId);
						
						
						toAdd.add(rowList);

					}
					String url = "jdbc:mariadb://localhost:3306/pos";
					String user = "root";
					String password = "";

					try (Connection connection = (Connection) DriverManager.getConnection(url, user, password)) {
						// Replace "your_table_name" with the actual name of your "purchase" table
						String addQuery = "INSERT INTO purchase VALUES (null, ?, ?, ?, ?, ?, ?)";
						try (PreparedStatement addStatement = connection.prepareStatement(addQuery)) {

							for (List<Object> rowValues : toAdd) {
						        addStatement.setString(1, rowValues.get(0).toString()); // Assuming productId is a string
						        addStatement.setString(2, rowValues.get(1).toString()); // Assuming quantity is a string
						        addStatement.setString(3, rowValues.get(2).toString()); // Assuming price is a string
						        addStatement.setString(4, rowValues.get(3).toString()); // Assuming size is a string
						        addStatement.setString(5, rowValues.get(4).toString()); // Assuming date is a string
						        addStatement.setString(6, rowValues.get(5).toString()); // Assuming userId is a string

						        	System.out.println(rowValues.get(3).toString());
								addStatement.executeUpdate();

							}
							
							
							table_load2();

						}
					} catch (SQLException ex) {
						ex.printStackTrace();
					}
					try (Connection connection = (Connection) DriverManager.getConnection(url, user, password)) {
						// Replace "your_table_name" with the actual name of your "purchase" table
						String deleteQuery = "DELETE FROM cart WHERE userId = " + GlobalVariables.userId;
						try (PreparedStatement deleteStatement = connection.prepareStatement(deleteQuery)) {

							deleteStatement.executeUpdate();
						}
					} catch (SQLException ex) {
						ex.printStackTrace();
					}
					table_load1();
					try (Connection connection = (Connection) DriverManager.getConnection(url, user, password)) {
						// Replace "your_table_name" with the actual name of your "product" table
						String updateQuery = "UPDATE product SET quantity = quantity - ? WHERE productId = ?";

						try (PreparedStatement updateStatement = connection.prepareStatement(updateQuery)) {

							for (int row = 0; row < rowCount; row++) {
								// Assuming that productId is stored as an Integer in the table
								Integer productId = (Integer) model.getValueAt(row, 1);

								// Assuming that quantity is stored as an Integer in the table
								Integer checkoutQuantity = (Integer) model.getValueAt(row, 4);

								// Set the parameter values for the PreparedStatement
								updateStatement.setInt(1, checkoutQuantity);
								updateStatement.setInt(2, productId);

								// Execute the update statement for each row
								updateStatement.executeUpdate();
							}
						}
					} catch (SQLException ex) {
						ex.printStackTrace();
					}

					// add to purchase

					JOptionPane.showMessageDialog(null, "check out successfully.", "Success",
							JOptionPane.INFORMATION_MESSAGE);
				}

			}
		});

		btnCheckOut.setBounds(20, 321, 167, 71);
		btnCheckOut.setVisible(true);
		panel_6.add(btnCheckOut);

		ListSelectionModel selectionModel = table.getSelectionModel();
		selectionModel.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				if (!e.getValueIsAdjusting()) {
					btnDeleteRow.setVisible(true);
					;
				}

			}
		});
	}

	private void addEditablePanelGrid(JPanel parentPanel) {
		JPanel scrollPanelContentCart = new JPanel();
		scrollPanelContentCart.setBackground(new Color(192, 192, 192));
		scrollPanelContentCart.setBorder(null);
		JScrollPane scrollPaneCart = new JScrollPane(scrollPanelContentCart,
				ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPaneCart.setViewportBorder(new LineBorder(new Color(128, 128, 128), 5));
		scrollPanelContentCart.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		scrollPaneCart.setLocation(0, 0);
		scrollPaneCart.setSize(1217, 395);

		int labelWidth = 200;
		int labelHeight = 350;

		try (Connection Connect =(Connection) DriverManager.getConnection(url, user, password)) {
		    String query = "SELECT * FROM product";

		    try (PreparedStatement pst = Connect.prepareStatement(query);
		         ResultSet rs = pst.executeQuery()) {

		        while (rs.next()) {
		            //if getstring quan > 0 
		            JPanel panel1 = createEditablePanel(rs.getInt("productId"), rs.getString("name"),
		                                                rs.getDouble("price"), rs.getString("image"), rs.getInt("quantity"));
		            panel1.setPreferredSize(new Dimension(labelWidth, labelHeight));
		            scrollPanelContentCart.add(panel1);
		        }

		    } // Resources are closed automatically here

		} catch (SQLException e) {
		    e.printStackTrace();
		}



		parentPanel.setLayout(null);
		parentPanel.add(scrollPaneCart);
	}

	private JPanel createEditablePanel(int productId, String initialTitle, Double price, String imagePath, int quantity) {
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		panel.setBorder(new LineBorder(new Color(0, 128, 128), 6));
		panel.setOpaque(true);

		// Panel for product number and title
		JPanel titlePanel = new JPanel(new BorderLayout());

		// Product number
		JLabel productNumberLabel = new JLabel(productId + "");
		titlePanel.add(productNumberLabel, BorderLayout.WEST);

		// Editable title
		JTextField titleField = new JTextField(initialTitle);
		titleField.setBackground(new Color(95, 158, 160));
		titleField.setFont(new Font("Georgia", Font.PLAIN, 11));
		titleField.setMaximumSize(new Dimension(500, 20));
		titleField.setEditable(false);
		titlePanel.add(titleField, BorderLayout.CENTER);

		panel.add(titlePanel);

		// Image Panel with JLabel
		JPanel imagePanel = new JPanel();
		imagePanel.setBorder(new LineBorder(new Color(0, 128, 128), 5, true));
		imagePanel.setPreferredSize(new Dimension(200, 300));
		
		
		
		try {
			// Assuming imagePath is a valid path to the image file
			ImageIcon imageIcon = new ImageIcon(imagePath);
			Image image = imageIcon.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT);
			ImageIcon scaledIcon = new ImageIcon(image);
			JLabel imageLabel = new JLabel(scaledIcon);
			if(imagePath == null) {
				imageLabel.setText("Image not Available");
			}

			// Create a JLabel to hold the scaled image
			

			// Add the image label to the image panel
			imagePanel.add(imageLabel);
		} catch (Exception e) {
			e.printStackTrace();
		}

		// Add the image panel to the main panel
		panel.add(imagePanel);

		// Editable PricePanel
		JPanel pricePanel = new JPanel();
		pricePanel.setBackground(new Color(255, 255, 255));
		pricePanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel priceLabel = new JLabel("₱" + price);
		priceLabel.setPreferredSize(new Dimension(150, 20));
		pricePanel.add(priceLabel);

		panel.add(pricePanel);

		// Quantity
		// part--------------------------------------------------------------------------------
		JPanel quantityAndSizePanel = new JPanel();
		quantityAndSizePanel.setBackground(new Color(255, 255, 255));
		quantityAndSizePanel.setLayout(new BoxLayout(quantityAndSizePanel, BoxLayout.X_AXIS));

		quantityAndSizePanel.setBorder(BorderFactory
				.createTitledBorder(BorderFactory.createLineBorder(new Color(0, 128, 128), 5), "Quantity and Size"));

		JPanel quantityPanel = new JPanel();
		quantityPanel.setLayout(new BoxLayout(quantityPanel, BoxLayout.X_AXIS));
		JTextField quantityField = new JTextField("1", 3);
		if(quantity < 1) {
			quantityField.setText("0");
		}
		quantityField.setEditable(false);
		quantityField.setHorizontalAlignment(SwingConstants.CENTER);

		JButton plusButton = new JButton("+");
		plusButton.setFocusable(false);
		JButton minusButton = new JButton("-");
		minusButton.setFocusable(false);

		plusButton.addActionListener(e -> {

			int currentQuantity = Integer.parseInt(quantityField.getText());
			if(currentQuantity < quantity) {
				quantityField.setText(String.valueOf(currentQuantity + 1));
			}
			
		});

		minusButton.addActionListener(e -> {
			int currentQuantity = Integer.parseInt(quantityField.getText());
			if (currentQuantity > 1) {
				quantityField.setText(String.valueOf(currentQuantity - 1));
			}
		});

		quantityPanel.add(minusButton);
		quantityPanel.add(quantityField);
		quantityPanel.add(plusButton);

		quantityAndSizePanel.add(quantityPanel);

		// Combo box size selection
		// part-----------------------------------------------------------------------
		String[] sizes = { "XS", "Small", "Medium", "Large", "XL" };
		JComboBox<String> sizeComboBox = new JComboBox<>(sizes);
		sizeComboBox.setFont(new Font("Arial", Font.BOLD, 11));
		sizeComboBox.setFocusable(false);

		sizeComboBox.setMaximumSize(new Dimension(90, 30));
		quantityAndSizePanel.add(sizeComboBox);

		quantityAndSizePanel.add(quantityPanel);

		panel.add(quantityAndSizePanel);

		// Add to Cart Part
		JPanel buttonPanel1 = new JPanel(new FlowLayout(FlowLayout.CENTER));
		buttonPanel1.setBackground(new Color(255, 255, 255));
		JButton addButton1 = new JButton("Add to Cart");
		addButton1.setBackground(new Color(95, 158, 160));
		addButton1.setFont(new Font("Century Gothic", Font.BOLD, 15));
		addButton1.setFocusable(false);
		if(quantity < 1) {
			addButton1.enable(false);
			addButton1.setEnabled(false);
			addButton1.setText("Out of Stock");
		}

		addButton1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// Create a dialog to gather additional information
				String url = "jdbc:mariadb://localhost:3306/pos";
				String user = "root";
				String password = "";

				try (Connection connection = (Connection) DriverManager.getConnection(url, user, password)) {
					// Replace "your_table_name" with the actual name of your "purchase" table
					String query = "SELECT `productId`, `quantity` FROM `product` WHERE 1";

					JPanel dialogPanel = new JPanel();
					dialogPanel.setLayout(new BoxLayout(dialogPanel, BoxLayout.Y_AXIS));

					// Product name
					JLabel nameLabel = new JLabel("Product: " + initialTitle);
					dialogPanel.add(nameLabel);

					// Price
					JLabel priceLabel = new JLabel("Price: ₱" + price);
					dialogPanel.add(priceLabel);

					// Size
					JLabel sizeLabel = new JLabel("Size: " + sizes[sizeComboBox.getSelectedIndex()]);
					dialogPanel.add(sizeLabel);

					// Quantity
					int selectedQuantity = Integer.parseInt(quantityField.getText());

					JLabel quantityLabel = new JLabel("Quantity: " + selectedQuantity);
					dialogPanel.add(quantityLabel);

					// Text area for displaying total
					JTextArea totalTextArea = new JTextArea();
					totalTextArea.setEditable(false);
					dialogPanel.add(new JLabel("Total:"));
					dialogPanel.add(totalTextArea);

					// Product number (assuming productnumberlabel is a JLabel)
					// Set the text for productNumberLabel before using it
					productNumberLabel.setText(productNumberLabel.getText()); // Replace this with the correct value

					JLabel productNumberLabelDialog = new JLabel("Product Number: " + productNumberLabel.getText());
					dialogPanel.add(productNumberLabelDialog);

					// Update total when quantity changes
					totalTextArea.setText("₱" + (selectedQuantity * price));

					int result = JOptionPane.showConfirmDialog(null, dialogPanel, "Add to Cart",
							JOptionPane.OK_CANCEL_OPTION);
					String productNumber = productNumberLabel.getText();

					try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {

						try (ResultSet resultSet = preparedStatement.executeQuery()) {
							int currentQuantity = 0; // Initialize to a default value

							while (resultSet.next()) {
								if (resultSet.getInt("productId") == (productId)) {
									currentQuantity = resultSet.getInt("quantity");
									break;
								}
							}
							int selectedQuantity1 = 1;

							if (selectedQuantity1 > currentQuantity) {
								JOptionPane.showMessageDialog(null, "Not enough quantity available in stock.", "Error",
										JOptionPane.ERROR_MESSAGE);
								return; // Do not proceed further
							}

						}
					}

					// If the user clicks OK, add the item to the cart
					// Inside your actionPerformed method or wherever you handle the "Add to
					// Database" button click
					if (result == JOptionPane.OK_OPTION) {
						String productName = initialTitle;
						String selectedSize = sizes[sizeComboBox.getSelectedIndex()];
						double selectedPrice = price;
						double totalPrice = selectedQuantity * selectedPrice;

						// Use the method to add the data to your table model
						addToCartTableModel(productId, selectedSize, selectedPrice, selectedQuantity, totalPrice,
								productNumber);

						// Update the JTable with the latest data

					}
				} catch (SQLException ex) {
					ex.printStackTrace();
				}
			}

		});

		addButton1.setPreferredSize(new Dimension(250, 50));
		addButton1.setBorder(BorderFactory.createLineBorder(new Color(0, 128, 128), 5));
		buttonPanel1.add(addButton1);

		panel.add(buttonPanel1);
		return panel;
	}

	private void addToDatabase(int productId, String selectedSize, double selectedPrice, int selectedQuantity,
			double totalPrice) {
		// Load the MariaDB JDBC driver
		try {
			Class.forName("org.mariadb.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
			// Handle the exception (e.g., log the error, throw a custom exception)
		}

		// Establish the database connection
		String url = "jdbc:mariadb://localhost:3306/pos";
		String user = "root";
		String password = "";

		try (Connection connection = (Connection) DriverManager.getConnection(url, user, password)) {
			// Replace "your_table_name" with the actual name of your "purchase" table
			String query = "INSERT INTO cart (productId, quantity, price, size, userId) VALUES (?, ?, ?, ?, ?)";
			try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
				preparedStatement.setInt(1, productId);
				preparedStatement.setInt(2, selectedQuantity);
				preparedStatement.setDouble(3, totalPrice);
				preparedStatement.setString(4, selectedSize);
				preparedStatement.setInt(5, GlobalVariables.userId);

				// Execute the insert statement
				preparedStatement.executeUpdate();
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	protected void addToCartTableModel(int productId, String selectedSize, double selectedPrice, int selectedQuantity,
			double totalPrice, String productNumber) {
		DefaultTableModel model = (DefaultTableModel) table.getModel();

//Check if the product is already in the cart
//Check if the product is already in the cart
		int rowCount = model.getRowCount();
		for (int i = 0; i < rowCount; i++) {
			// Assuming column 0 contains product IDs and column 1 contains sizes
			Object existingProductObj = model.getValueAt(i, 1);
			Object existingSizeObj = model.getValueAt(i, 5);

			// Convert the objects to strings (if they are not already strings)
			String existingProduct = existingProductObj != null ? existingProductObj.toString() : "";
			String existingSize = existingSizeObj != null ? existingSizeObj.toString() : "";

			// Check for duplicate product and size
			if (existingProduct.equals(String.valueOf(productId)) && existingSize.equals(selectedSize)) {
				// Product is already in the cart, show a dialog
				JOptionPane.showMessageDialog(null, "This product is already in your cart.", "Duplicate Product",
						JOptionPane.WARNING_MESSAGE);
				return; // Do not add the duplicate product to the cart
			} 
		}
		addToDatabase(productId, selectedSize, selectedPrice, selectedQuantity, totalPrice);
		
		model.addRow(new Object[]{productId, selectedSize, selectedQuantity, totalPrice, productNumber});
		table_load1();
	}

	private void updateTotalPrice(String[] prices, JTextField quantityField, JComboBox<String> sizeComboBox,
			JLabel priceLabel) {
		// TODO Auto-generated method stub
	}

	private void showPanel(JPanel panel) {
		Home.setVisible(panel == Home);
		Product.setVisible(panel == Product);
		Cart.setVisible(panel == Cart);
		OrderHistory.setVisible(panel == OrderHistory);

		Account2.setVisible(panel == Account2);

	}
}
