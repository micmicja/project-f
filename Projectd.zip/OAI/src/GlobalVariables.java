
public class GlobalVariables {
	public static int userId = 0;
	public static String  name = "";
	public static String  loaction = "";
	public static String  phone = "";
	public static String  username = "";
	public static String  password = "";
	
}

