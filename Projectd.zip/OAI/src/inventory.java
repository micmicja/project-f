import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class inventory {

	private JFrame frame;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void In() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					inventory window = new inventory();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public inventory() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(64, 128, 128));
		frame.setBounds(100, 100, 895, 598);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Inventory");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNewLabel.setBounds(374, 11, 181, 68);
		frame.getContentPane().add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(176, 73, 637, 305);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
			},
			new String[] {
				"New column", "New column", "New column", "New column", "New column"
			}
		));
		scrollPane.setViewportView(table);
		
		JButton inventory = new JButton("Inventory");
		inventory.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ea) {
				try {
					
					
					JOptionPane.showMessageDialog(null,"Error Already in Inventory");

				}catch(Exception e) 
								{System.out.print(e);}
				
				
			
				
			}
		});
		inventory.setFont(new Font("Segoe UI Black", Font.BOLD, 15));
		inventory.setBounds(10, 85, 131, 62);
		frame.getContentPane().add(inventory);
		
		JButton btnAddItem = new JButton("Add Item");
		btnAddItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ea) {
				try {
					
					//Additem.In();
					frame.setVisible(false);

				}catch(Exception e) 
								{System.out.print(e);}
				
				
			}
		});
		btnAddItem.setFont(new Font("Segoe UI Black", Font.BOLD, 15));
		btnAddItem.setBounds(10, 176, 131, 62);
		frame.getContentPane().add(btnAddItem);
		
		JButton EditDelete = new JButton("Edit/Delete");
		EditDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ea) {
				try {
					
					//Additem.In();
					frame.setVisible(false);

				}catch(Exception e) 
								{System.out.print(e);}
			}
		});
		EditDelete.setFont(new Font("Segoe UI Black", Font.BOLD, 15));
		EditDelete.setBounds(10, 265, 131, 62);
		frame.getContentPane().add(EditDelete);
		
		JButton Account = new JButton("Account");
		Account.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent ea) {
			try {
				
				//Additem.In();
				frame.setVisible(false);

			}catch(Exception e) 
							{System.out.print(e);}
			}
		});
		Account.setFont(new Font("Segoe UI Black", Font.BOLD, 15));
		Account.setBounds(10, 357, 131, 62);
		frame.getContentPane().add(Account);
	}
}
