import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLayeredPane;
import javax.swing.JDesktopPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextField;
import javax.swing.JTabbedPane;

public class inventory {

	private JFrame frame;
	private JTable table;
	private JPanel Sales;
	private JPanel Invento;
	private JPanel AddItem;
	private JPanel Accounts;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTable table_1;
	private JTable table_2;
	private JTable table_3;
	private JTable table_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;

	/**
	 * Launch the application.
	 */
	public static void In() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					inventory window = new inventory();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public inventory() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 185, 559);
		frame.getContentPane().add(panel);
		
		
		
		JButton btnNewButton = new JButton("Inventory");
		btnNewButton.setBounds(24, 106, 136, 51);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Invento.setVisible(true);
				AddItem.setVisible(false);
				Accounts.setVisible(false);
				Sales.setVisible(false);
			}
		});
		panel.setLayout(null);
		
		
		btnNewButton.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		panel.add(btnNewButton);
		
		JButton btnAddItem = new JButton("Item ");
		btnAddItem.setBounds(24, 190, 136, 51);
		btnAddItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Invento.setVisible(false);
				AddItem.setVisible(true);
				Accounts.setVisible(false);
				Sales.setVisible(false);
			}
		});
		btnAddItem.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		panel.add(btnAddItem);
		
		JButton btnEditdelete = new JButton("Sales");
		btnEditdelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Invento.setVisible(false);
				AddItem.setVisible(false);
				Accounts.setVisible(false);
				Sales.setVisible(true);
			}
		});
		btnEditdelete.setBounds(24, 282, 136, 51);
		btnEditdelete.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		panel.add(btnEditdelete);
		
		JButton btnAccount = new JButton("Account");
		btnAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Invento.setVisible(false);
				AddItem.setVisible(false);
				Accounts.setVisible(true);
				Sales.setVisible(false);
			}
		});
		btnAccount.setBounds(24, 374, 136, 51);
		btnAccount.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		panel.add(btnAccount);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(184, 0, 695, 559);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		
		
		
		
		Invento = new JPanel();
		Invento.setBackground(new Color(192, 192, 192));
		Invento.setBounds(0, 0, 695, 559);
		panel_1.add(Invento);
		Invento.setLayout(null);
		
		
		JLabel lblNewLabel = new JLabel("Current Inventory");
		lblNewLabel.setFont(new Font("Sylfaen", Font.PLAIN, 30));
		lblNewLabel.setBounds(234, 11, 245, 64);
		Invento.add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(46, 68, 603, 480);
		Invento.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
			},
			new String[] {
				"Product Code", "Product Name", "Quantity", "Cost Price", "Selling Price", "Brand"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, true, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		table.getColumnModel().getColumn(0).setResizable(false);
		table.getColumnModel().getColumn(2).setResizable(false);
		table.getColumnModel().getColumn(4).setResizable(false);
		table.getColumnModel().getColumn(5).setResizable(false);
		scrollPane.setViewportView(table);
		
		Accounts = new JPanel();
		Accounts.setBounds(0, 0, 695, 559);
		panel_1.add(Accounts);
		Accounts.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(33, 62, 634, 472);
		Accounts.add(tabbedPane);
		
		JPanel panel_2 = new JPanel();
		tabbedPane.addTab("Admin", null, panel_2, null);
		panel_2.setLayout(null);
		
		JScrollPane scrollPane_4 = new JScrollPane();
		scrollPane_4.setBounds(10, 11, 609, 219);
		panel_2.add(scrollPane_4);
		
		table_4 = new JTable();
		table_4.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null},
			},
			new String[] {
				"Full Name", "Address", "Contact Numer", "username", "Password", "Acces"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class, String.class, Object.class, Object.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		table_4.getColumnModel().getColumn(0).setResizable(false);
		table_4.getColumnModel().getColumn(1).setResizable(false);
		table_4.getColumnModel().getColumn(2).setResizable(false);
		table_4.getColumnModel().getColumn(3).setResizable(false);
		table_4.getColumnModel().getColumn(4).setResizable(false);
		table_4.getColumnModel().getColumn(5).setResizable(false);
		scrollPane_4.setViewportView(table_4);
		
		JLabel lblNewLabel_1_1_1_1_2 = new JLabel("Full Name");
		lblNewLabel_1_1_1_1_2.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_2.setBounds(20, 251, 74, 18);
		panel_2.add(lblNewLabel_1_1_1_1_2);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(109, 251, 159, 20);
		panel_2.add(textField_5);
		
		JLabel lblNewLabel_1_1_1_1_2_1 = new JLabel("Address");
		lblNewLabel_1_1_1_1_2_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_2_1.setBounds(20, 280, 74, 18);
		panel_2.add(lblNewLabel_1_1_1_1_2_1);
		
		JLabel lblNewLabel_1_1_1_1_2_2 = new JLabel("Contact No.");
		lblNewLabel_1_1_1_1_2_2.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_2_2.setBounds(20, 307, 81, 18);
		panel_2.add(lblNewLabel_1_1_1_1_2_2);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(109, 282, 159, 20);
		panel_2.add(textField_6);
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		textField_7.setBounds(109, 307, 159, 20);
		panel_2.add(textField_7);
		
		JLabel lblNewLabel_1_1_1_1_2_3 = new JLabel("UserName");
		lblNewLabel_1_1_1_1_2_3.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_2_3.setBounds(376, 251, 74, 18);
		panel_2.add(lblNewLabel_1_1_1_1_2_3);
		
		textField_8 = new JTextField();
		textField_8.setColumns(10);
		textField_8.setBounds(460, 251, 159, 20);
		panel_2.add(textField_8);
		
		textField_9 = new JTextField();
		textField_9.setColumns(10);
		textField_9.setBounds(460, 280, 159, 20);
		panel_2.add(textField_9);
		
		textField_10 = new JTextField();
		textField_10.setColumns(10);
		textField_10.setBounds(460, 307, 159, 20);
		panel_2.add(textField_10);
		
		JLabel lblNewLabel_1_1_1_1_2_3_1 = new JLabel("Password");
		lblNewLabel_1_1_1_1_2_3_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_2_3_1.setBounds(376, 280, 74, 18);
		panel_2.add(lblNewLabel_1_1_1_1_2_3_1);
		
		JLabel lblNewLabel_1_1_1_1_2_3_1_1 = new JLabel("Access");
		lblNewLabel_1_1_1_1_2_3_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_2_3_1_1.setBounds(390, 309, 60, 18);
		panel_2.add(lblNewLabel_1_1_1_1_2_3_1_1);
		
		JButton btnNewButton_1_3 =new JButton("Add");
		btnNewButton_1_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1_3.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		btnNewButton_1_3.setBounds(170, 348, 98, 43);
		panel_2.add(btnNewButton_1_3);
		
		JButton btnNewButton_1_3_1 = new JButton("Edit");
		btnNewButton_1_3_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		btnNewButton_1_3_1.setBounds(295, 348, 98, 43);
		panel_2.add(btnNewButton_1_3_1);
		
		JButton btnNewButton_1_3_1_1 = new JButton("Delete");
		btnNewButton_1_3_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		btnNewButton_1_3_1_1.setBounds(416, 348, 98, 43);
		panel_2.add(btnNewButton_1_3_1_1);
		
		JPanel panel_3 = new JPanel();
		tabbedPane.addTab("Customer", null, panel_3, null);
		panel_3.setLayout(null);
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(10, 11, 575, 205);
		panel_3.add(scrollPane_3);
		
		table_3 = new JTable();
		table_3.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null},
			},
			new String[] {
				"No.", "Full Name", "Address", "Contact Numer", "UserName", "Password"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				true, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		table_3.getColumnModel().getColumn(1).setResizable(false);
		table_3.getColumnModel().getColumn(2).setResizable(false);
		table_3.getColumnModel().getColumn(3).setResizable(false);
		table_3.getColumnModel().getColumn(4).setResizable(false);
		table_3.getColumnModel().getColumn(5).setResizable(false);
		scrollPane_3.setViewportView(table_3);
		
		JLabel lblAccounts = new JLabel("Accounts");
		lblAccounts.setFont(new Font("Sylfaen", Font.PLAIN, 30));
		lblAccounts.setBounds(253, 11, 148, 64);
		Accounts.add(lblAccounts);
		
		 Sales = new JPanel();
		Sales.setBounds(0, 0, 695, 559);
		panel_1.add(Sales);
		Sales.setLayout(null);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 89, 665, 301);
		Sales.add(scrollPane_1);
		
		table_1 = new JTable();
		table_1.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, "", null, null},
			},
			new String[] {
				"Purchased Id", "Product Code", "Product name", "Quantity", "Total Cost"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		table_1.getColumnModel().getColumn(0).setResizable(false);
		table_1.getColumnModel().getColumn(1).setResizable(false);
		table_1.getColumnModel().getColumn(2).setResizable(false);
		table_1.getColumnModel().getColumn(3).setResizable(false);
		table_1.getColumnModel().getColumn(4).setResizable(false);
		scrollPane_1.setViewportView(table_1);
		
		JLabel lblEditdelete = new JLabel("Sales");
		lblEditdelete.setFont(new Font("Sylfaen", Font.PLAIN, 30));
		lblEditdelete.setBounds(276, 11, 148, 64);
		Sales.add(lblEditdelete);
		
		AddItem = new JPanel();
		AddItem.setBounds(0, 0, 695, 559);
		panel_1.add(AddItem);
		AddItem.setLayout(null);
		
		JLabel lblAddItem = new JLabel("Add  Edit Delete Item");
		lblAddItem.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 30));
		lblAddItem.setBounds(188, 22, 293, 64);
		AddItem.add(lblAddItem);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"nike", "mike", "era"}));
		comboBox.setBounds(134, 327, 159, 22);
		AddItem.add(comboBox);
		
		JLabel lblNewLabel_1 = new JLabel("Product Code");
		lblNewLabel_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(27, 298, 114, 18);
		AddItem.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Product Name");
		lblNewLabel_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1.setBounds(27, 327, 114, 18);
		AddItem.add(lblNewLabel_1_1);
		
		textField = new JTextField();
		textField.setBounds(499, 298, 159, 20);
		AddItem.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Quantity");
		lblNewLabel_1_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1.setBounds(27, 360, 114, 18);
		AddItem.add(lblNewLabel_1_1_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(499, 360, 159, 20);
		AddItem.add(textField_1);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("Cost Price");
		lblNewLabel_1_1_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1.setBounds(399, 298, 74, 18);
		AddItem.add(lblNewLabel_1_1_1_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(499, 328, 159, 20);
		AddItem.add(textField_2);
		
		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("Selling Price");
		lblNewLabel_1_1_1_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_1.setBounds(399, 328, 82, 18);
		AddItem.add(lblNewLabel_1_1_1_1_1);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(134, 360, 159, 20);
		AddItem.add(textField_3);
		
		JLabel lblNewLabel_1_1_1_1_1_1 = new JLabel("Brand");
		lblNewLabel_1_1_1_1_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_1_1.setBounds(399, 360, 56, 18);
		AddItem.add(lblNewLabel_1_1_1_1_1_1);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(134, 298, 159, 20);
		AddItem.add(textField_4);
		
		JButton btnNewButton_1 = new JButton("Add item");
		btnNewButton_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		btnNewButton_1.setBounds(144, 391, 98, 43);
		AddItem.add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("Edit");
		btnNewButton_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		btnNewButton_1_1.setBounds(275, 391, 98, 43);
		AddItem.add(btnNewButton_1_1);
		
		JButton btnNewButton_1_2 = new JButton("Delete");
		btnNewButton_1_2.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		btnNewButton_1_2.setBounds(409, 389, 98, 43);
		AddItem.add(btnNewButton_1_2);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(29, 97, 629, 190);
		AddItem.add(scrollPane_2);
		
		table_2 = new JTable();
		table_2.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
			},
			new String[] {
				"Product Code", "Product Name", "Quantity", "Cost Price", "Selling Price", "Brand"
			}
		));
		scrollPane_2.setViewportView(table_2);
		frame.setBounds(100, 100, 895, 598);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
