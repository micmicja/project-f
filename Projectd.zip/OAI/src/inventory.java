import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.sql.*;
import java.util.Vector;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import net.proteanit.sql.DbUtils;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLayeredPane;
import javax.swing.JDesktopPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextField;
import javax.swing.JTabbedPane;

public class inventory {
	private String url = "jdbc:mysql://localhost:3306/projectd";
	private	String user = "root";
	private	String password = "";
	private JFrame frame;
	private JTable table;
	private JPanel Sales;
	private JPanel Invento;
	private JPanel AddItem;
	private JPanel Accounts;
	private JTextField CostPrice;
	private JTextField Brand;
	private JTextField SellingPrice;
	private JTextField Quantity;
	private JTextField ProductC;
	private JTable table_1;
	private JTable table_2;
	private JTable table_3;
	private JTable table_4;
	private JTextField Fname;
	private JTextField location;
	private JTextField phone;
	private JTextField username;
	private JTextField passWord;
	private JTextField userType;
	private JTextField ProductN;
	private JTextField Size;
	private JTextField DateReceive;
	private void table_load1() {
		
		 try (Connection connect = DriverManager.getConnection(url, user, password)){
		        String query = "SELECT * FROM products";
		        try (PreparedStatement pst = connect.prepareStatement(query);
		             ResultSet rs = pst.executeQuery()) {

		            // Assuming 'table' is a JTable
		            table.setModel(DbUtils.resultSetToTableModel(rs));

		        } // Resources are closed automatically here

		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		}
	private void table_load() {
		
		 try (Connection connect = DriverManager.getConnection(url, user, password)){
		        String query = "SELECT * FROM products";
		        try (PreparedStatement pst = connect.prepareStatement(query);
		             ResultSet rs = pst.executeQuery()) {

		            // Assuming 'table' is a JTable
		            table_2.setModel(DbUtils.resultSetToTableModel(rs));

		        } // Resources are closed automatically here

		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		}
	private void table_load2() {
		
		 try (Connection connect = DriverManager.getConnection(url, user, password)){
		        String query = "SELECT * FROM `users` WHERE usertype='admin'";
		        try (PreparedStatement pst = connect.prepareStatement(query);
		             ResultSet rs = pst.executeQuery()) {

		            // Assuming 'table' is a JTable
		            table_4.setModel(DbUtils.resultSetToTableModel(rs));

		        } // Resources are closed automatically here

		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		}
	private void table_load3() {
		
		 try (Connection connect = DriverManager.getConnection(url, user, password)){
		        String query = "SELECT * FROM `users` WHERE usertype='customer'";
		        try (PreparedStatement pst = connect.prepareStatement(query);
		             ResultSet rs = pst.executeQuery()) {

		            // Assuming 'table' is a JTable
		            table_3.setModel(DbUtils.resultSetToTableModel(rs));

		        } // Resources are closed automatically here

		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		}
	
	/**
	 * Launch the application.
	 */
	public static void In() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					inventory window = new inventory();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public inventory() {
		initialize();
		table_load1();
		table_load();
		table_load2();	
		table_load3();
		
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBackground(new Color(0, 128, 128));
		frame.setResizable(false);
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.getContentPane().setLayout(null);
		 frame.setLocationRelativeTo(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(192, 192, 192));
		panel.setBounds(0, 0, 185, 559);
		frame.getContentPane().add(panel);
		
		
		
		JButton btnNewButton = new JButton("Inventory");
		btnNewButton.setBounds(24, 106, 136, 51);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Invento.setVisible(true);
				AddItem.setVisible(false);
				Accounts.setVisible(false);
				Sales.setVisible(false);
			}
		});
		panel.setLayout(null);
		
		
		btnNewButton.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		panel.add(btnNewButton);
		
		JButton btnAddItem = new JButton("Item ");
		btnAddItem.setBounds(24, 190, 136, 51);
		btnAddItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Invento.setVisible(false);
				AddItem.setVisible(true);
				Accounts.setVisible(false);
				Sales.setVisible(false);
			}
		});
		btnAddItem.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		panel.add(btnAddItem);
		
		JButton btnEditdelete = new JButton("Sales");
		btnEditdelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Invento.setVisible(false);
				AddItem.setVisible(false);
				Accounts.setVisible(false);
				Sales.setVisible(true);
			}
		});
		btnEditdelete.setBounds(24, 282, 136, 51);
		btnEditdelete.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		panel.add(btnEditdelete);
		
		JButton btnAccount = new JButton("Account");
		btnAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Invento.setVisible(false);
				AddItem.setVisible(false);
				Accounts.setVisible(true);
				Sales.setVisible(false);
			}
		});
		btnAccount.setBounds(24, 374, 136, 51);
		btnAccount.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		panel.add(btnAccount);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 128, 128));
		panel_1.setBounds(184, 0, 695, 559);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		
		
		
		
		Invento = new JPanel();
		Invento.setForeground(new Color(0, 128, 128));
		Invento.setBackground(new Color(0, 128, 128));
		Invento.setBounds(0, 0, 695, 559);
		panel_1.add(Invento);
		Invento.setLayout(null);
		
		
		JLabel lblNewLabel = new JLabel("Current Inventory");
		lblNewLabel.setFont(new Font("Sylfaen", Font.PLAIN, 30));
		lblNewLabel.setBounds(234, 11, 245, 64);
		Invento.add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 68, 675, 480);
		Invento.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Product Code", "Product Name", "Quantity", "Cost Price", "Selling Price", "Brand"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, true, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		table.getColumnModel().getColumn(0).setResizable(false);
		table.getColumnModel().getColumn(2).setResizable(false);
		table.getColumnModel().getColumn(4).setResizable(false);
		table.getColumnModel().getColumn(5).setResizable(false);
		
		scrollPane.setViewportView(table);
		
		
		AddItem = new JPanel();
		AddItem.setBackground(new Color(0, 128, 128));
		AddItem.setBounds(0, 0, 695, 559);
		panel_1.add(AddItem);
		AddItem.setLayout(null);
		
		JLabel lblAddItem = new JLabel("Add  Edit Delete Item");
		lblAddItem.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 30));
		lblAddItem.setBounds(188, 22, 293, 64);
		AddItem.add(lblAddItem);
		
		JLabel lblNewLabel_1 = new JLabel("Product Code");
		lblNewLabel_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(27, 298, 114, 18);
		AddItem.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Product Name");
		lblNewLabel_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1.setBounds(27, 327, 114, 18);
		AddItem.add(lblNewLabel_1_1);
		
		CostPrice = new JTextField();
		CostPrice.setBackground(new Color(192, 192, 192));
		CostPrice.setBounds(499, 298, 159, 20);
		AddItem.add(CostPrice);
		CostPrice.setColumns(10);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Quantity");
		lblNewLabel_1_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1.setBounds(27, 356, 114, 18);
		AddItem.add(lblNewLabel_1_1_1);
		
		Brand = new JTextField();
		Brand.setColumns(10);
		Brand.setBounds(499, 356, 159, 20);
		AddItem.add(Brand);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("Cost Price");
		lblNewLabel_1_1_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1.setBounds(399, 298, 74, 18);
		AddItem.add(lblNewLabel_1_1_1_1);
		
		SellingPrice = new JTextField();
		SellingPrice.setColumns(10);
		SellingPrice.setBounds(499, 328, 159, 20);
		AddItem.add(SellingPrice);
		
		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("Selling Price");
		lblNewLabel_1_1_1_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_1.setBounds(399, 328, 82, 18);
		AddItem.add(lblNewLabel_1_1_1_1_1);
		
		Quantity = new JTextField();
		Quantity.setColumns(10);
		Quantity.setBounds(134, 356, 159, 20);
		AddItem.add(Quantity);
		
		JLabel lblNewLabel_1_1_1_1_1_1 = new JLabel("Brand");
		lblNewLabel_1_1_1_1_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_1_1.setBounds(399, 356, 56, 18);
		AddItem.add(lblNewLabel_1_1_1_1_1_1);
		
		ProductC = new JTextField();
		ProductC.setColumns(10);
		ProductC.setBounds(134, 298, 159, 20);
		AddItem.add(ProductC);
		
		JButton btnNewButton_1 = new JButton("Add item");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			    try (Connection connect = DriverManager.getConnection(url, user, password)) {
			        String sql = "INSERT INTO products"
			                + "(productcode, productname, quantity, costprice, sellprice, brand,selectedSize,DateRecieve)"
			                + "VALUES(?, ?, ?, ?, ?, ?,?,?)";

			        try (PreparedStatement prepStat = connect.prepareStatement(sql)) {
			            prepStat.setString(1, ProductC.getText());
			            prepStat.setString(2, ProductN.getText());
			            prepStat.setString(3, Quantity.getText()); // Assuming this is the correct column for quantity
			            prepStat.setString(4, CostPrice.getText());
			            prepStat.setString(5, SellingPrice.getText());
			            prepStat.setString(6, Brand.getText());
			            prepStat.setString(7, Size.getText());
			            prepStat.setString(8, DateReceive.getText());

			            int rowsAffected = prepStat.executeUpdate();

			            // Check if the data was inserted successfully
			            if (rowsAffected > 0) {
			                JOptionPane.showMessageDialog(null, "Added data in the database successfully");

			                // Add a new row to the JTable
			                DefaultTableModel tblModel = (DefaultTableModel) table_2.getModel();
			                Object[] rowData = {ProductC.getText(), ProductN.getText(), Quantity.getText(),
			                        CostPrice.getText(), SellingPrice.getText(), Brand.getText(),Size.getText(),DateReceive.getText(),};
			                DefaultTableModel tblMode2 = (DefaultTableModel) table.getModel();
			                Object[] rowDataa = {ProductC.getText(), ProductN.getText(), Quantity.getText(),
			                        CostPrice.getText(), SellingPrice.getText(), Brand.getText(),Size.getText(),DateReceive.getText(),};
			                tblModel.addRow(rowData);
			                tblMode2.addRow(rowDataa);
			                // Clear the text fields after successful insertion
			                ProductC.setText("");
			                ProductN.setText("");
			                Quantity.setText("");
			                CostPrice.setText("");
			                SellingPrice.setText("");
			                Brand.setText("");
			                Size.setText("");
			                DateReceive.setText("");
			            } else {
			                JOptionPane.showMessageDialog(null, "Failed to add data in the database");
			            }
			        } catch (SQLException e2) {
			            e2.printStackTrace();
			        }
			    } catch (SQLException e1) {
			        e1.printStackTrace();
			    }
			}

			
			
		});
		
		btnNewButton_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		btnNewButton_1.setBounds(145, 437, 98, 43);
		AddItem.add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("Edit");
		btnNewButton_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		btnNewButton_1_1.setBounds(275, 437, 98, 43);
		AddItem.add(btnNewButton_1_1);
		
		JButton btnNewButton_1_2 = new JButton("Delete");
		btnNewButton_1_2.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		btnNewButton_1_2.setBounds(408, 437, 98, 43);
		AddItem.add(btnNewButton_1_2);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(10, 97, 675, 190);
		AddItem.add(scrollPane_2);
		
		table_2 = new JTable();
		table_2.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null},
			},
			new String[] {
				"Product Code", "Product Name", "Quantity", "Cost Price", "Selling Price", "Brand", "Date Receive", "Size"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		table_2.getColumnModel().getColumn(0).setResizable(false);
		table_2.getColumnModel().getColumn(1).setResizable(false);
		table_2.getColumnModel().getColumn(1).setPreferredWidth(93);
		table_2.getColumnModel().getColumn(2).setResizable(false);
		table_2.getColumnModel().getColumn(3).setResizable(false);
		table_2.getColumnModel().getColumn(4).setResizable(false);
		table_2.getColumnModel().getColumn(5).setResizable(false);
		table_2.getColumnModel().getColumn(6).setResizable(false);
		table_2.getColumnModel().getColumn(6).setPreferredWidth(98);
		table_2.getColumnModel().getColumn(7).setResizable(false);
		scrollPane_2.setViewportView(table_2);
		
		ProductN = new JTextField();
		ProductN.setColumns(10);
		ProductN.setBounds(134, 327, 159, 20);
		AddItem.add(ProductN);
		
		JLabel lblNewLabel_1_1_1_2 = new JLabel("Size");
		lblNewLabel_1_1_1_2.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_2.setBounds(27, 385, 114, 18);
		AddItem.add(lblNewLabel_1_1_1_2);
		
		Size = new JTextField();
		Size.setColumns(10);
		Size.setBounds(134, 385, 159, 20);
		AddItem.add(Size);
		
		JLabel Date = new JLabel("Date");
		Date.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		Date.setBounds(399, 385, 114, 18);
		AddItem.add(Date);
		
		DateReceive = new JTextField();
		DateReceive.setColumns(10);
		DateReceive.setBounds(499, 385, 159, 20);
		AddItem.add(DateReceive);
		
		Accounts = new JPanel();
		Accounts.setBackground(new Color(0, 128, 128));
		Accounts.setBounds(0, 0, 695, 559);
		panel_1.add(Accounts);
		Accounts.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(33, 62, 634, 472);
		Accounts.add(tabbedPane);
		
		JPanel panel_2 = new JPanel();
		tabbedPane.addTab("Admin", null, panel_2, null);
		panel_2.setLayout(null);
		
		JScrollPane scrollPane_4 = new JScrollPane();
		scrollPane_4.setBounds(10, 11, 609, 219);
		panel_2.add(scrollPane_4);
		
		table_4 = new JTable();
		table_4.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null},
			},
			new String[] {
				"Full Name", "Address", "Contact Numer", "username", "Password", "Acces"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class, String.class, Object.class, Object.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		table_4.getColumnModel().getColumn(0).setResizable(false);
		table_4.getColumnModel().getColumn(1).setResizable(false);
		table_4.getColumnModel().getColumn(2).setResizable(false);
		table_4.getColumnModel().getColumn(3).setResizable(false);
		table_4.getColumnModel().getColumn(4).setResizable(false);
		table_4.getColumnModel().getColumn(5).setResizable(false);
		scrollPane_4.setViewportView(table_4);
		
		JLabel lblNewLabel_1_1_1_1_2 = new JLabel("Full Name");
		lblNewLabel_1_1_1_1_2.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_2.setBounds(20, 251, 74, 18);
		panel_2.add(lblNewLabel_1_1_1_1_2);
		
		Fname = new JTextField();
		Fname.setColumns(10);
		Fname.setBounds(109, 251, 159, 20);
		panel_2.add(Fname);
		
		JLabel lblNewLabel_1_1_1_1_2_1 = new JLabel("Address");
		lblNewLabel_1_1_1_1_2_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_2_1.setBounds(20, 280, 74, 18);
		panel_2.add(lblNewLabel_1_1_1_1_2_1);
		
		JLabel lblNewLabel_1_1_1_1_2_2 = new JLabel("Contact No.");
		lblNewLabel_1_1_1_1_2_2.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_2_2.setBounds(20, 307, 81, 18);
		panel_2.add(lblNewLabel_1_1_1_1_2_2);
		
		location = new JTextField();
		location.setColumns(10);
		location.setBounds(109, 282, 159, 20);
		panel_2.add(location);
		
		phone = new JTextField();
		phone.setColumns(10);
		phone.setBounds(109, 307, 159, 20);
		panel_2.add(phone);
		
		JLabel lblNewLabel_1_1_1_1_2_3 = new JLabel("UserName");
		lblNewLabel_1_1_1_1_2_3.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_2_3.setBounds(376, 251, 74, 18);
		panel_2.add(lblNewLabel_1_1_1_1_2_3);
		
		username = new JTextField();
		username.setColumns(10);
		username.setBounds(460, 251, 159, 20);
		panel_2.add(username);
		
		passWord = new JTextField();
		passWord.setColumns(10);
		passWord.setBounds(460, 280, 159, 20);
		panel_2.add(passWord);
		
		userType = new JTextField();
		userType.setColumns(10);
		userType.setBounds(460, 307, 159, 20);
		panel_2.add(userType);
		
		JLabel lblNewLabel_1_1_1_1_2_3_1 = new JLabel("Password");
		lblNewLabel_1_1_1_1_2_3_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_2_3_1.setBounds(376, 280, 74, 18);
		panel_2.add(lblNewLabel_1_1_1_1_2_3_1);
		
		JLabel lblNewLabel_1_1_1_1_2_3_1_1 = new JLabel("userType");
		lblNewLabel_1_1_1_1_2_3_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_2_3_1_1.setBounds(390, 309, 60, 18);
		panel_2.add(lblNewLabel_1_1_1_1_2_3_1_1);
		
		JButton btnNewButton_1_3 =new JButton("Add");
		btnNewButton_1_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try (Connection connect = DriverManager.getConnection(url, user, password)) {
				    String sql = "INSERT INTO users"
				            + "(name, location, phone, username, password, usertype)"
				            + "VALUES(?, ?, ?, ?, ?, ?)";

				    try (PreparedStatement prepStat = connect.prepareStatement(sql)) {
				        prepStat.setString(1, Fname.getText());
				        prepStat.setString(2, location.getText());
				        prepStat.setString(3, phone.getText()); // Assuming this is the correct column for quantity
				        prepStat.setString(4, username.getText());
				        prepStat.setString(5, passWord.getText());
				        prepStat.setString(6, userType.getText());

				        int rowsAffected = prepStat.executeUpdate();
				        if (rowsAffected > 0) {
			                JOptionPane.showMessageDialog(null, "Added data in the database successfully");

			                // Add a new row to the JTable
			                DefaultTableModel tblModel = (DefaultTableModel) table_4.getModel();
			                Object[] rowData = {Fname.getText(), location.getText(), phone.getText(),
			                		username.getText(), passWord.getText(), userType.getText()};
			               
			                tblModel.addRow(rowData);
			                Fname.setText("");
					        location.setText("");
					        phone.setText("");
					        username.setText("");
					        passWord.setText("");
					        userType.setText("");

			                // Clear the text fields after successful insertion

			            } else {
			                JOptionPane.showMessageDialog(null, "Failed to add data in the database");
			            }
				        
				    } catch (SQLException e2) {
				        e2.printStackTrace();
				    }
				} catch (SQLException e1) {
				    e1.printStackTrace();
				}

				
				
				
				
			}
		});
		btnNewButton_1_3.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		btnNewButton_1_3.setBounds(170, 348, 98, 43);
		panel_2.add(btnNewButton_1_3);
		
		JButton btnNewButton_1_3_1 = new JButton("Edit");
		btnNewButton_1_3_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		btnNewButton_1_3_1.setBounds(295, 348, 98, 43);
		panel_2.add(btnNewButton_1_3_1);
		
		JButton btnNewButton_1_3_1_1 = new JButton("Delete");
		btnNewButton_1_3_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		btnNewButton_1_3_1_1.setBounds(416, 348, 98, 43);
		panel_2.add(btnNewButton_1_3_1_1);
		
		JPanel panel_3 = new JPanel();
		tabbedPane.addTab("Customer", null, panel_3, null);
		panel_3.setLayout(null);
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(10, 11, 575, 205);
		panel_3.add(scrollPane_3);
		
		table_3 = new JTable();
		table_3.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null},
			},
			new String[] {
				"No.", "Full Name", "Address", "Contact Numer", "UserName", "Password"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				true, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		table_3.getColumnModel().getColumn(1).setResizable(false);
		table_3.getColumnModel().getColumn(2).setResizable(false);
		table_3.getColumnModel().getColumn(3).setResizable(false);
		table_3.getColumnModel().getColumn(4).setResizable(false);
		table_3.getColumnModel().getColumn(5).setResizable(false);
		scrollPane_3.setViewportView(table_3);
		
		JLabel lblAccounts = new JLabel("Accounts");
		lblAccounts.setFont(new Font("Sylfaen", Font.PLAIN, 30));
		lblAccounts.setBounds(253, 11, 148, 64);
		Accounts.add(lblAccounts);
		
		 Sales = new JPanel();
		 Sales.setBackground(new Color(0, 128, 128));
		Sales.setBounds(0, 0, 695, 559);
		panel_1.add(Sales);
		Sales.setLayout(null);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 89, 665, 301);
		Sales.add(scrollPane_1);
		
		table_1 = new JTable();
		table_1.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, "", null, null},
			},
			new String[] {
				"Purchased Id", "Product Code", "Product name", "Quantity", "Total Cost"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		table_1.getColumnModel().getColumn(0).setResizable(false);
		table_1.getColumnModel().getColumn(1).setResizable(false);
		table_1.getColumnModel().getColumn(2).setResizable(false);
		table_1.getColumnModel().getColumn(3).setResizable(false);
		table_1.getColumnModel().getColumn(4).setResizable(false);
		scrollPane_1.setViewportView(table_1);
		
		
		JLabel lblEditdelete = new JLabel("Sales");
		lblEditdelete.setFont(new Font("Sylfaen", Font.PLAIN, 30));
		lblEditdelete.setBounds(276, 11, 148, 64);
		Sales.add(lblEditdelete);
		frame.setBounds(100, 100, 895, 598);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
