import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.table.DefaultTableModel;

import net.proteanit.sql.DbUtils;

public class inventory {
	private String url = "jdbc:mariadb://localhost:3306/pos";
	private String user = "root";
	private String password = "";
	private JFrame frame;
	private JPanel Sales;
	private JPanel AddItem;
	private JPanel Accounts;
	private JTextField CostPrice;
	private JTextField Brand;
	private JTextField SellingPrice;
	private JTextField Quantity;
	private JTextField ProductC;
	private JTable table_1;
	private JTable table_2;
	private JTable table_3;
	private JTable table_4;
	private JTextField Fname;
	private JTextField location;
	private JTextField phone;
	private JTextField username;
	private JTextField passWord;
	private JTextField userType;
	private JTextField ProductN;
	private JTextField id;

	private void table_load() {

		try (Connection connect = DriverManager.getConnection(url, user, password)) {
			String query = "SELECT  `productId` as `Product Code`, `name` as `Product`, `brand` as `Brand`, `cost` as `Cost`, `price` as `Selling Price`, `quantity` FROM `product`";
			try (PreparedStatement pst = connect.prepareStatement(query); ResultSet rs = pst.executeQuery()) {

				// Assuming 'table' is a JTable
				table_2.setModel(DbUtils.resultSetToTableModel(rs));

			} // Resources are closed automatically here

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void table_load22() {

		try (Connection connect = (Connection) DriverManager.getConnection(url, user, password)) {
			String query = "SELECT purchaseId as `#`, users.name as `Name`, product.productId as `SKU`, product.name as `Product Name`, brand as `Brand`, purchase.quantity as `Quantity`, size as 'Size', purchase.price as `Total Price`, date as `Date` FROM purchase INNER JOIN product ON  purchase.productId = product.productId INNER JOIN users ON purchase.userId= users.id ";
			;
			try (PreparedStatement pst = connect.prepareStatement(query);

					ResultSet rs = pst.executeQuery()) {

				// Assuming 'table' is a JTable
				table_1.setModel(DbUtils.resultSetToTableModel(rs));

			} // Resources are closed automatically here

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void table_load2() {

		try (Connection connect = DriverManager.getConnection(url, user, password)) {
			String query = "SELECT * FROM `users` WHERE usertype='admin'";
			try (PreparedStatement pst = connect.prepareStatement(query); ResultSet rs = pst.executeQuery()) {

				// Assuming 'table' is a JTable
				table_4.setModel(DbUtils.resultSetToTableModel(rs));

			} // Resources are closed automatically here

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void table_load3() {

		try (Connection connect = DriverManager.getConnection(url, user, password)) {
			String query = "SELECT * FROM `users` WHERE usertype='customer'";
			try (PreparedStatement pst = connect.prepareStatement(query); ResultSet rs = pst.executeQuery()) {

				// Assuming 'table' is a JTable
				table_3.setModel(DbUtils.resultSetToTableModel(rs));

			} // Resources are closed automatically here

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Launch the application.
	 */
	public static void In() {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					inventory window = new inventory();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public inventory() {

		initialize();
		table_load();
		table_load2();
		table_load3();
		table_load22();

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBackground(new Color(0, 128, 128));
		frame.setResizable(false);
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.getContentPane().setLayout(null);
		frame.setLocationRelativeTo(null);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(192, 192, 192));
		panel.setBounds(0, 0, 185, 559);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		JButton btnAddItem = new JButton("Item ");
		btnAddItem.setBounds(26, 122, 136, 51);
		btnAddItem.setFocusable(false);
		btnAddItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				AddItem.setVisible(true);
				Accounts.setVisible(false);
				Sales.setVisible(false);
			}
		});
		btnAddItem.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		panel.add(btnAddItem);

		JButton btnEditdelete = new JButton("Sales");
		btnEditdelete.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				AddItem.setVisible(false);
				Accounts.setVisible(false);
				Sales.setVisible(true);
			}
		});
		btnEditdelete.setBounds(26, 214, 136, 51);
		btnEditdelete.setFocusable(false);
		btnEditdelete.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		panel.add(btnEditdelete);

		JButton btnAccount = new JButton("Account");
		btnAccount.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				AddItem.setVisible(false);
				Accounts.setVisible(true);
				Sales.setVisible(false);
			}
		});
		btnAccount.setBounds(26, 306, 136, 51);
		btnAccount.setFocusable(false);
		btnAccount.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		panel.add(btnAccount);

		JButton btnLogout = new JButton("Logout");
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				OAI window = new OAI();
				window.frame.setVisible(true);
			}
		});
		btnLogout.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		btnLogout.setFocusable(false);
		btnLogout.setBounds(26, 392, 136, 51);
		panel.add(btnLogout);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 128, 128));
		panel_1.setBounds(184, 0, 695, 559);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);

		AddItem = new JPanel();
		AddItem.setBackground(new Color(0, 128, 128));
		AddItem.setBounds(0, 0, 695, 559);
		panel_1.add(AddItem);
		AddItem.setLayout(null);

		JLabel lblAddItem = new JLabel("Add  Edit Delete Item");
		lblAddItem.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 30));
		lblAddItem.setBounds(188, 22, 293, 64);
		AddItem.add(lblAddItem);

		JLabel productlable = new JLabel("Product Code");
		productlable.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		productlable.setBounds(27, 298, 114, 18);
		productlable.setVisible(false);
		AddItem.add(productlable);

		JLabel lblNewLabel_1_1 = new JLabel("Product Name");
		lblNewLabel_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1.setBounds(27, 327, 114, 18);
		AddItem.add(lblNewLabel_1_1);

		CostPrice = new JTextField();
		CostPrice.setBackground(new Color(192, 192, 192));
		CostPrice.setBounds(499, 298, 159, 20);
		AddItem.add(CostPrice);
		CostPrice.setColumns(10);

		JLabel lblNewLabel_1_1_1 = new JLabel("Quantity");
		lblNewLabel_1_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1.setBounds(27, 356, 114, 18);
		AddItem.add(lblNewLabel_1_1_1);

		Brand = new JTextField();
		Brand.setColumns(10);
		Brand.setBounds(499, 356, 159, 20);
		AddItem.add(Brand);

		JLabel lblNewLabel_1_1_1_1 = new JLabel("Cost Price");
		lblNewLabel_1_1_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1.setBounds(399, 298, 74, 18);
		AddItem.add(lblNewLabel_1_1_1_1);

		SellingPrice = new JTextField();
		SellingPrice.setColumns(10);
		SellingPrice.setBounds(499, 328, 159, 20);
		AddItem.add(SellingPrice);

		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("Selling Price");
		lblNewLabel_1_1_1_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_1.setBounds(399, 328, 82, 18);
		AddItem.add(lblNewLabel_1_1_1_1_1);

		Quantity = new JTextField();
		Quantity.setColumns(10);
		Quantity.setBounds(134, 356, 159, 20);
		AddItem.add(Quantity);

		JLabel lblNewLabel_1_1_1_1_1_1 = new JLabel("Brand");
		lblNewLabel_1_1_1_1_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_1_1.setBounds(399, 356, 56, 18);
		AddItem.add(lblNewLabel_1_1_1_1_1_1);

		ProductC = new JTextField();
		ProductC.setColumns(10);
		ProductC.setBounds(134, 298, 159, 20);
		ProductC.setVisible(false);
		AddItem.add(ProductC);

		JButton btnNewButton_1 = new JButton("Add item");
		btnNewButton_1.setFocusable(false);
		btnNewButton_1.setVisible(false);
		btnNewButton_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try (Connection connect = DriverManager.getConnection(url, user, password)) {
					String sql = "INSERT INTO product ( name, quantity, cost, price, brand) VALUES (?, ?, ?, ?, ?)";
					if (ProductN.getText().isEmpty() || Quantity.getText().isEmpty() || CostPrice.getText().isEmpty()
							|| SellingPrice.getText().isEmpty() || Brand.getText().isEmpty()) {
						JOptionPane.showMessageDialog(null, "Please fill in all the fields", "Error",
								JOptionPane.ERROR_MESSAGE);
						return; // Stop further execution if any field is empty
					}
					try (PreparedStatement prepStat = connect.prepareStatement(sql)) {

						prepStat.setString(1, ProductN.getText());
						prepStat.setString(2, Quantity.getText());
						prepStat.setString(3, CostPrice.getText());
						prepStat.setString(4, SellingPrice.getText());
						prepStat.setString(5, Brand.getText());

						int rowsAffected = prepStat.executeUpdate();

						// Check if the data was inserted successfully
						if (rowsAffected > 0) {
							JOptionPane.showMessageDialog(null, "Added data in the database successfully");
							table_load();

							// Clear the text fields after successful insertion
							ProductC.setText("");
							ProductN.setText("");
							Quantity.setText("");
							CostPrice.setText("");
							SellingPrice.setText("");
							Brand.setText("");
						} else {
							JOptionPane.showMessageDialog(null, "Failed to add data in the database");
						}
					} catch (SQLException ex) {
						ex.printStackTrace();
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}

		});

		btnNewButton_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		btnNewButton_1.setBounds(109, 438, 98, 43);
		AddItem.add(btnNewButton_1);

		JButton btnNewButton_1_1 = new JButton("Edit");
		btnNewButton_1_1.setFocusable(false);
		btnNewButton_1_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int selectedRow = -1;
				int selectedRow2 = -1;

				try (Connection connect = DriverManager.getConnection(url, user, password)) {
					String sql = "UPDATE product SET name=?, quantity=?, cost=?, price=?, brand=? WHERE productId=?";

					try (PreparedStatement prepStat = connect.prepareStatement(sql)) {
						prepStat.setString(1, ProductN.getText());
						prepStat.setString(2, Quantity.getText());
						prepStat.setString(3, CostPrice.getText());
						prepStat.setString(4, SellingPrice.getText());
						prepStat.setString(5, Brand.getText());
						prepStat.setString(6, ProductC.getText());

						int rowsAffected = prepStat.executeUpdate();

						// Check if the data was updated successfully
						if (rowsAffected > 0) {
							JOptionPane.showMessageDialog(null, "Updated data in the database successfully");
							table_load();

							// Update the JTable
							DefaultTableModel tblModel = (DefaultTableModel) table_2.getModel();
							// Assuming ProductC is in the first column (index 0)
							for (int i = 0; i < tblModel.getRowCount(); i++) {
								if (tblModel.getValueAt(i, 0).equals(ProductC.getText())) {
									selectedRow = i;
									break;
								}
							}

							if (selectedRow != -1) {
								tblModel.setValueAt(ProductN.getText(), selectedRow, 1);
								tblModel.setValueAt(Quantity.getText(), selectedRow, 2);
								tblModel.setValueAt(CostPrice.getText(), selectedRow, 3);
								tblModel.setValueAt(SellingPrice.getText(), selectedRow, 4);
								tblModel.setValueAt(Brand.getText(), selectedRow, 5);
							}

						} else {
							JOptionPane.showMessageDialog(null, "Failed to update data in the database");

						}
					} catch (SQLException ex) {
						ex.printStackTrace();
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}

		});
		btnNewButton_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		btnNewButton_1_1.setBounds(239, 438, 98, 43);
		AddItem.add(btnNewButton_1_1);

		JButton btnNewButton_1_2 = new JButton("Delete");
		btnNewButton_1_2.setFocusable(false);
		btnNewButton_1_2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try (Connection connect = DriverManager.getConnection(url, user, password)) {
					String sql = "DELETE FROM product WHERE productId = ?";

					try (PreparedStatement prepStat = connect.prepareStatement(sql)) {
						prepStat.setString(1, ProductC.getText());

						int rowsAffected = prepStat.executeUpdate();

						// Check if the data was deleted successfully
						if (rowsAffected > 0) {
							JOptionPane.showMessageDialog(null, "Deleted data from the database successfully");
							table_load();

							// Remove the row from the JTable
							DefaultTableModel tblModel = (DefaultTableModel) table_2.getModel();
							int selectedRow = findRowIndexByProductCode(tblModel, ProductC.getText());
							if (selectedRow != -1) {
								tblModel.removeRow(selectedRow);
							}

							// Clear the text fields after successful deletion
							ProductC.setText("");
							ProductN.setText("");
							Quantity.setText("");
							CostPrice.setText("");
							SellingPrice.setText("");
							Brand.setText("");
						} else {
							JOptionPane.showMessageDialog(null, "Failed to delete data from the database");
						}
					} catch (SQLException ex) {
						ex.printStackTrace();
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}

			// Helper method to find the index of a row by product code in the JTable
			private int findRowIndexByProductCode(DefaultTableModel model, String productCode) {
				for (int i = 0; i < model.getRowCount(); i++) {
					if (model.getValueAt(i, 0).equals(productCode)) { // Assuming product code is in the first column
																		// (index 0)
						return i;
					}
				}
				return -1; // Not found
			}

		});
		btnNewButton_1_2.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		btnNewButton_1_2.setBounds(372, 438, 98, 43);
		AddItem.add(btnNewButton_1_2);

		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(10, 97, 675, 190);
		AddItem.add(scrollPane_2);

		table_2 = new JTable();
		table_2.setModel(new DefaultTableModel(new Object[][] {}, new String[] {

		}));
		scrollPane_2.setViewportView(table_2);

		ProductN = new JTextField();
		ProductN.setColumns(10);
		ProductN.setBounds(134, 327, 159, 20);
		AddItem.add(ProductN);

		JButton Search = new JButton("Search");
		Search.setFocusable(false);
		Search.setVisible(false);
		Search.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try (Connection connect = DriverManager.getConnection(url, user, password)) {
					String query = "SELECT * FROM product WHERE productId = ?";
					PreparedStatement statement = connect.prepareStatement(query);

					// Assuming EmployeeID is an integer
					int employeeID = Integer.parseInt(ProductC.getText());
					statement.setInt(1, employeeID);

					ResultSet resultSet = statement.executeQuery();

					if (resultSet.next()) {
						ProductN.setText(resultSet.getString("name"));
						Quantity.setText(resultSet.getString("quantity"));
						CostPrice.setText(resultSet.getString("cost"));
						SellingPrice.setText(resultSet.getString("price"));
						Brand.setText(resultSet.getString("brand"));

					} else {
						// Handle the case where no records were found for the given EmployeeID
						// You may want to clear the text fields or display a message
						// textField_1.setText("");
						// textField_10.setText("");
						// ... (similarly for other text fields)
						JOptionPane.showMessageDialog(null, "Product NO. not found!!!" + JOptionPane.ERROR_MESSAGE);
					}

				} catch (Exception ex) {
					ex.printStackTrace();
					// Handle exceptions appropriately (e.g., log or display an error message)
				}

			}
		});
		Search.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		Search.setBounds(501, 438, 98, 43);
		AddItem.add(Search);

		JButton aDD = new JButton("Add Item");
		aDD.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnNewButton_1.setVisible(true);
				ProductC.setVisible(false);
				productlable.setVisible(false);
				Search.setVisible(false);
				// Clear the text fields after successful insertion
				ProductC.setText("");
				ProductN.setText("");
				Quantity.setText("");
				CostPrice.setText("");
				SellingPrice.setText("");
				Brand.setText("");

			}
		});
		aDD.setBounds(10, 67, 89, 23);
		AddItem.add(aDD);

		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ProductC.setVisible(true);
				productlable.setVisible(true);
				Search.setVisible(true);
				btnNewButton_1.setVisible(false);
				// Clear the text fields after successful insertion
				ProductC.setText("");
				ProductN.setText("");
				Quantity.setText("");
				CostPrice.setText("");
				SellingPrice.setText("");
				Brand.setText("");

			}
		});
		btnSearch.setBounds(596, 67, 89, 23);
		AddItem.add(btnSearch);

		Accounts = new JPanel();
		Accounts.setBackground(new Color(0, 128, 128));
		Accounts.setBounds(0, 0, 695, 559);
		panel_1.add(Accounts);
		Accounts.setLayout(null);

		JTabbedPane tabbedPane = new JTabbedPane(SwingConstants.TOP);
		tabbedPane.setBounds(33, 62, 634, 472);
		Accounts.add(tabbedPane);

		JPanel panel_3 = new JPanel();
		tabbedPane.addTab("Customer", null, panel_3, null);
		panel_3.setLayout(null);

		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(10, 11, 575, 205);
		panel_3.add(scrollPane_3);

		table_3 = new JTable();
		table_3.setModel(new DefaultTableModel(new Object[][] { { null, null, null, null, null, null }, },
				new String[] { "No.", "Full Name", "Address", "Contact Numer", "UserName", "Password" }) {
			boolean[] columnEditables = new boolean[] { true, false, false, false, false, false };

			@Override
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		table_3.getColumnModel().getColumn(1).setResizable(false);
		table_3.getColumnModel().getColumn(2).setResizable(false);
		table_3.getColumnModel().getColumn(3).setResizable(false);
		table_3.getColumnModel().getColumn(4).setResizable(false);
		table_3.getColumnModel().getColumn(5).setResizable(false);
		scrollPane_3.setViewportView(table_3);

		JPanel panel_2 = new JPanel();
		tabbedPane.addTab("Admin", null, panel_2, null);
		panel_2.setLayout(null);

		JScrollPane scrollPane_4 = new JScrollPane();
		scrollPane_4.setBounds(10, 11, 609, 219);
		panel_2.add(scrollPane_4);

		table_4 = new JTable();
		table_4.setModel(new DefaultTableModel(new Object[][] { { null, null, null, null, null, null }, },
				new String[] { "Full Name", "Address", "Contact Numer", "username", "Password", "Acces" }) {
			Class[] columnTypes = new Class[] { String.class, String.class, String.class, Object.class, Object.class,
					Object.class };

			@Override
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}

			boolean[] columnEditables = new boolean[] { false, false, false, false, false, false };

			@Override
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		table_4.getColumnModel().getColumn(0).setResizable(false);
		table_4.getColumnModel().getColumn(1).setResizable(false);
		table_4.getColumnModel().getColumn(2).setResizable(false);
		table_4.getColumnModel().getColumn(3).setResizable(false);
		table_4.getColumnModel().getColumn(4).setResizable(false);
		table_4.getColumnModel().getColumn(5).setResizable(false);
		scrollPane_4.setViewportView(table_4);

		JLabel lblNewLabel_1_1_1_1_2 = new JLabel("Full Name");
		lblNewLabel_1_1_1_1_2.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_2.setBounds(20, 289, 74, 18);
		panel_2.add(lblNewLabel_1_1_1_1_2);

		Fname = new JTextField();
		Fname.setColumns(10);
		Fname.setBounds(109, 289, 159, 20);
		panel_2.add(Fname);

		JLabel lblNewLabel_1_1_1_1_2_1 = new JLabel("Address");
		lblNewLabel_1_1_1_1_2_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_2_1.setBounds(20, 318, 74, 18);
		panel_2.add(lblNewLabel_1_1_1_1_2_1);

		JLabel lblNewLabel_1_1_1_1_2_2 = new JLabel("Contact No.");
		lblNewLabel_1_1_1_1_2_2.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_2_2.setBounds(20, 345, 81, 18);
		panel_2.add(lblNewLabel_1_1_1_1_2_2);

		location = new JTextField();
		location.setColumns(10);
		location.setBounds(109, 320, 159, 20);
		panel_2.add(location);

		phone = new JTextField();
		phone.setColumns(10);
		phone.setBounds(109, 345, 159, 20);
		panel_2.add(phone);

		JLabel lblNewLabel_1_1_1_1_2_3 = new JLabel("UserName");
		lblNewLabel_1_1_1_1_2_3.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_2_3.setBounds(376, 289, 74, 18);
		panel_2.add(lblNewLabel_1_1_1_1_2_3);

		username = new JTextField();
		username.setColumns(10);
		username.setBounds(460, 289, 159, 20);
		panel_2.add(username);

		passWord = new JTextField();
		passWord.setColumns(10);
		passWord.setBounds(460, 318, 159, 20);
		panel_2.add(passWord);

		userType = new JTextField();

		userType.setText("admin");

		panel_2.add(userType);

		JLabel lblNewLabel_1_1_1_1_2_3_1 = new JLabel("Password");
		lblNewLabel_1_1_1_1_2_3_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_2_3_1.setBounds(376, 318, 74, 18);
		panel_2.add(lblNewLabel_1_1_1_1_2_3_1);

		JButton btnNewButton_1_3 = new JButton("Add");
		btnNewButton_1_3.setFocusable(false);
		btnNewButton_1_3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try (Connection connect = DriverManager.getConnection(url, user, password)) {
					String sql = "INSERT INTO users" + "(name, location, phone, username, password, usertype)"
							+ "VALUES(?, ?, ?, ?, ?, ?)";

					try (PreparedStatement prepStat = connect.prepareStatement(sql)) {
						prepStat.setString(1, Fname.getText());
						prepStat.setString(2, location.getText());
						prepStat.setString(3, phone.getText()); // Assuming this is the correct column for quantity
						prepStat.setString(4, username.getText());
						prepStat.setString(5, passWord.getText());
						prepStat.setString(6, userType.getText());

						int rowsAffected = prepStat.executeUpdate();
						if (rowsAffected > 0) {
							JOptionPane.showMessageDialog(null, "Added data in the database successfully");

							// Add a new row to the JTable
							DefaultTableModel tblModel = (DefaultTableModel) table_4.getModel();
							Object[] rowData = { Fname.getText(), location.getText(), phone.getText(),
									username.getText(), passWord.getText(), userType.getText() };

							tblModel.addRow(rowData);
							Fname.setText("");
							location.setText("");
							phone.setText("");
							username.setText("");
							passWord.setText("");
							userType.setText("");

							// Clear the text fields after successful insertion

						} else {
							JOptionPane.showMessageDialog(null, "Failed to add data in the database");
						}
						table_load2();

					} catch (SQLException e2) {
						e2.printStackTrace();
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}

			}
		});
		btnNewButton_1_3.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		btnNewButton_1_3.setBounds(97, 374, 98, 43);
		panel_2.add(btnNewButton_1_3);

		JButton btnNewButton_1_3_1 = new JButton("Edit");
		btnNewButton_1_3_1.setFocusable(false);
		btnNewButton_1_3_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int selectedRow = -1;

				try (Connection connect = DriverManager.getConnection(url, user, password)) {
					String sql = "UPDATE users SET name=?, location=?, phone=?, username=?, password=?, userType=? WHERE id=?";

					try (PreparedStatement prepStat = connect.prepareStatement(sql)) {
						prepStat.setString(1, Fname.getText());
						prepStat.setString(2, location.getText());
						prepStat.setString(3, phone.getText());
						prepStat.setString(4, username.getText());
						prepStat.setString(5, passWord.getText());
						prepStat.setString(6, userType.getText());
						prepStat.setString(7, id.getText());

						int rowsAffected = prepStat.executeUpdate();

						// Check if the data was updated successfully
						if (rowsAffected > 0) {
							JOptionPane.showMessageDialog(null, "Updated data in the database successfully");

							// Update the JTable
							DefaultTableModel tblModel = (DefaultTableModel) table_4.getModel();

							// Assuming id is in the first column (index 0)
							for (int i = 0; i < tblModel.getRowCount(); i++) {
								if (tblModel.getValueAt(i, 0).equals(Integer.parseInt(id.getText()))) {
									selectedRow = i;
									break;
								}
							}

							if (selectedRow != -1) {
								tblModel.setValueAt(Fname.getText(), selectedRow, 1);
								tblModel.setValueAt(location.getText(), selectedRow, 2);
								tblModel.setValueAt(phone.getText(), selectedRow, 3);
								tblModel.setValueAt(username.getText(), selectedRow, 4);
								tblModel.setValueAt(passWord.getText(), selectedRow, 5);
								tblModel.setValueAt(userType.getText(), selectedRow, 6);
							}
						} else {
							JOptionPane.showMessageDialog(null, "Failed to update data in the database");
						}
					} catch (SQLException ex) {
						ex.printStackTrace();
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}

			}
		});
		btnNewButton_1_3_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		btnNewButton_1_3_1.setBounds(222, 374, 98, 43);
		panel_2.add(btnNewButton_1_3_1);

		JButton btnNewButton_1_3_1_1 = new JButton("Delete");
		btnNewButton_1_3_1_1.setFocusable(false);
		btnNewButton_1_3_1_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try (Connection connect = DriverManager.getConnection(url, user, password)) {
					String sql = "DELETE FROM users WHERE id = ?";

					try (PreparedStatement prepStat = connect.prepareStatement(sql)) {
						// Assuming id is an integer
						prepStat.setInt(1, Integer.parseInt(id.getText()));

						int rowsAffected = prepStat.executeUpdate();

						// Check if the data was deleted successfully
						if (rowsAffected > 0) {
							JOptionPane.showMessageDialog(null, "Deleted data from the database successfully");

							// Remove the row from the JTable
							DefaultTableModel tblModel = (DefaultTableModel) table_4.getModel();
							int selectedRow = findRowIndex(tblModel, Integer.parseInt(id.getText()));
							if (selectedRow != -1) {
								tblModel.removeRow(selectedRow);
							}

							// Clear the text fields after successful deletion
							Fname.setText("");
							location.setText("");
							phone.setText("");
							username.setText("");
							passWord.setText("");
							userType.setText("");

						} else {
							JOptionPane.showMessageDialog(null, "Failed to delete data from the database");
						}
					} catch (SQLException ex) {
						ex.printStackTrace();
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}

			// Helper method to find the index of a row by id in the JTable
			private int findRowIndex(DefaultTableModel model, int id) {
				for (int i = 0; i < model.getRowCount(); i++) {
					if (Integer.parseInt(model.getValueAt(i, 0).toString()) == id) {
						return i;
					}
				}
				return -1; // Not found
			}

		});
		btnNewButton_1_3_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		btnNewButton_1_3_1_1.setBounds(343, 374, 98, 43);
		panel_2.add(btnNewButton_1_3_1_1);

		JButton btnNewButton_1_3_1_1_1 = new JButton("Search");
		btnNewButton_1_3_1_1_1.setFocusable(false);
		btnNewButton_1_3_1_1_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try (Connection connect = DriverManager.getConnection(url, user, password)) {
					String query = "SELECT * FROM users WHERE id = ?";
					PreparedStatement statement = connect.prepareStatement(query);

					// Assuming EmployeeID is an integer
					int employeeID = Integer.parseInt(id.getText());
					statement.setInt(1, employeeID);

					// Set the other parameters here using appropriate methods like setString or
					// setInt

					ResultSet resultSet = statement.executeQuery();

					if (resultSet.next()) {
						// Retrieve data as needed
						id.setText(resultSet.getString("id"));
						Fname.setText(resultSet.getString("name"));
						location.setText(resultSet.getString("location"));
						phone.setText(resultSet.getString("phone"));
						username.setText(resultSet.getString("username"));
						passWord.setText(resultSet.getString("password"));
						userType.setText(resultSet.getString("usertype"));
					} else {
						// Handle the case where no records were found for the given parameters
						JOptionPane.showMessageDialog(null, "Record not found!!!" + JOptionPane.ERROR_MESSAGE);
					}
				} catch (NumberFormatException ex) {
					// Handle the case where the input string is not a valid integer
					JOptionPane.showMessageDialog(null, "Invalid input for ID!" + JOptionPane.ERROR_MESSAGE);
				} catch (Exception ex) {
					ex.printStackTrace();
					// Handle other exceptions appropriately (e.g., log or display an error message)
				}

			}
		});
		btnNewButton_1_3_1_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		btnNewButton_1_3_1_1_1.setBounds(458, 374, 98, 43);
		panel_2.add(btnNewButton_1_3_1_1_1);

		id = new JTextField();
		id.setColumns(10);
		id.setBounds(460, 345, 159, 20);
		panel_2.add(id);

		JLabel lblNewLabel_1_1_1_1_2_4 = new JLabel("Id");
		lblNewLabel_1_1_1_1_2_4.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_2_4.setBounds(419, 345, 31, 18);
		panel_2.add(lblNewLabel_1_1_1_1_2_4);

		JLabel lblAccounts = new JLabel("Accounts");
		lblAccounts.setFont(new Font("Sylfaen", Font.PLAIN, 30));
		lblAccounts.setBounds(253, 11, 148, 64);
		Accounts.add(lblAccounts);

		Sales = new JPanel();
		Sales.setBackground(new Color(0, 128, 128));
		Sales.setBounds(0, 0, 695, 559);
		panel_1.add(Sales);
		Sales.setLayout(null);

		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 89, 665, 301);
		Sales.add(scrollPane_1);

		table_1 = new JTable();
		table_1.setModel(new DefaultTableModel(new Object[][] { { null, null, "", null, null }, },
				new String[] { "Purchased Id", "Product Code", "Product name", "Quantity", "Total Cost" }) {
			boolean[] columnEditables = new boolean[] { false, false, false, false, false };

			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		table_1.getColumnModel().getColumn(0).setResizable(false);
		table_1.getColumnModel().getColumn(1).setResizable(false);
		table_1.getColumnModel().getColumn(2).setResizable(false);
		table_1.getColumnModel().getColumn(3).setResizable(false);
		table_1.getColumnModel().getColumn(4).setResizable(false);
		scrollPane_1.setViewportView(table_1);

		JLabel lblEditdelete = new JLabel("Sales");
		lblEditdelete.setFont(new Font("Sylfaen", Font.PLAIN, 30));
		lblEditdelete.setBounds(276, 11, 148, 64);
		Sales.add(lblEditdelete);
		frame.setBounds(100, 100, 895, 598);
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
	}
}
