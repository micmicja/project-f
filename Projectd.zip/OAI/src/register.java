import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JPasswordField;

public class register {
	
	private JFrame frame;
	private final JPanel panel = new JPanel();
	private JTextField Name;
	private JTextField Location;
	private JTextField phone;
	private JTextField username;
	private JTextField Password;
	private JTextField txtCustomer;

	/**
	 * Launch the application.
	 */
	public static void In() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					register window = new register();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public register() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 539, 357);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		panel.setBounds(0, 0, 523, 318);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		Name = new JTextField();
		Name.setHorizontalAlignment(SwingConstants.LEFT);
		Name.setForeground(Color.BLACK);
		Name.setFont(new Font("Georgia", Font.PLAIN, 11));
		Name.setColumns(10);
		Name.setBackground(new Color(0, 128, 128));
		Name.setBounds(122, 42, 270, 20);
		panel.add(Name);
		
		JLabel lblNewLabel_1 = new JLabel("FullName:");
		lblNewLabel_1.setFont(new Font("Georgia", Font.PLAIN, 11));
		lblNewLabel_1.setBounds(48, 45, 68, 14);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("UserName:");
		lblNewLabel_1_1.setFont(new Font("Georgia", Font.PLAIN, 11));
		lblNewLabel_1_1.setBounds(48, 160, 68, 14);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Address:");
		lblNewLabel_1_1_1.setFont(new Font("Georgia", Font.PLAIN, 11));
		lblNewLabel_1_1_1.setBounds(48, 82, 68, 14);
		panel.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("Password:");
		lblNewLabel_1_1_2.setFont(new Font("Georgia", Font.PLAIN, 11));
		lblNewLabel_1_1_2.setBounds(48, 203, 68, 14);
		panel.add(lblNewLabel_1_1_2);
		
		JLabel lblNewLabel_1_1_3 = new JLabel("Contact#:");
		lblNewLabel_1_1_3.setFont(new Font("Georgia", Font.PLAIN, 11));
		lblNewLabel_1_1_3.setBounds(48, 120, 68, 14);
		panel.add(lblNewLabel_1_1_3);
		
		Location = new JTextField();
		Location.setHorizontalAlignment(SwingConstants.LEFT);
		Location.setForeground(Color.BLACK);
		Location.setFont(new Font("Georgia", Font.PLAIN, 11));
		Location.setColumns(10);
		Location.setBackground(new Color(0, 128, 128));
		Location.setBounds(122, 79, 337, 20);
		panel.add(Location);
		
		phone = new JTextField();
		phone.setHorizontalAlignment(SwingConstants.LEFT);
		phone.setForeground(Color.BLACK);
		phone.setFont(new Font("Georgia", Font.PLAIN, 11));
		phone.setColumns(10);
		phone.setBackground(new Color(0, 128, 128));
		phone.setBounds(122, 117, 152, 20);
		panel.add(phone);
		
		username = new JTextField();
		username.setHorizontalAlignment(SwingConstants.LEFT);
		username.setForeground(Color.BLACK);
		username.setFont(new Font("Georgia", Font.PLAIN, 11));
		username.setColumns(10);
		username.setBackground(new Color(0, 128, 128));
		username.setBounds(122, 157, 135, 20);
		panel.add(username);
		
		Password = new JTextField();
		Password.setHorizontalAlignment(SwingConstants.LEFT);
		Password.setForeground(Color.BLACK);
		Password.setFont(new Font("Georgia", Font.PLAIN, 11));
		Password.setColumns(10);
		Password.setBackground(new Color(0, 128, 128));
		Password.setBounds(122, 197, 135, 20);
		panel.add(Password);
		
		JButton btnRegister = new JButton("Register");
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 String url = "jdbc:mysql://localhost:3306/projectd";
					String user = "root";
					String passWord = "";
				try (Connection connect = DriverManager.getConnection(url, user, passWord)) {
				    String sql = "INSERT INTO users"
				            + "(name, location, phone, username, password, usertype)"
				            + "VALUES(?, ?, ?, ?, ?, ?)";

				    try (PreparedStatement prepStat = connect.prepareStatement(sql)) {
				        prepStat.setString(1, Name.getText());
				        prepStat.setString(2, Location.getText());
				        prepStat.setString(3, phone.getText()); // Assuming this is the correct column for quantity
				        prepStat.setString(4, username.getText());
				        prepStat.setString(5, Password.getText());
				        prepStat.setString(6, txtCustomer.getText());

				        int rowsAffected = prepStat.executeUpdate();
				        JOptionPane.showMessageDialog(null, "Register successfully");
				        System.out.println(rowsAffected + " row(s)");

				        // Clear the text fields after successful insertion
				        Name.setText("");
				        Location.setText("");
				        phone.setText("");
				        username.setText("");
				        Password.setText("");
				        txtCustomer.setText("");

				    } catch (SQLException e2) {
				        e2.printStackTrace();
				    }
				} catch (SQLException e1) {
				    e1.printStackTrace();
				}
				
				
				
			}
		});
		btnRegister.setBounds(132, 264, 89, 23);
		panel.add(btnRegister);
		
		JButton btnBackToMainmenu = new JButton("Back to Mainmenu");
		btnBackToMainmenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				OAI.main(null);
				frame.dispose();
				
			}
		});
		btnBackToMainmenu.setBounds(273, 264, 152, 23);
		panel.add(btnBackToMainmenu);
		
		JLabel lblSignup = new JLabel("SignUp");
		lblSignup.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		lblSignup.setBounds(212, 1, 89, 30);
		panel.add(lblSignup);
		
		txtCustomer = new JTextField();
		txtCustomer.setEnabled(false);
		txtCustomer.setText("customer");
		txtCustomer.setEditable(false);
		txtCustomer.setHorizontalAlignment(SwingConstants.LEFT);
		txtCustomer.setForeground(new Color(255, 255, 255));
		txtCustomer.setFont(new Font("Georgia", Font.PLAIN, 11));
		txtCustomer.setColumns(10);
		txtCustomer.setBackground(new Color(255, 255, 255));
		txtCustomer.setBounds(146, 228, 75, 20);
		panel.add(txtCustomer);
	}
}
