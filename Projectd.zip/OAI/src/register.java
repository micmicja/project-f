import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.border.LineBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.JTextComponent;

public class register {

	private JFrame frame;
	private final JPanel panel = new JPanel();
	private JTextField Name;
	private JTextField Location;
	private JTextField phone;
	private JTextField username;
	private JTextField Password;
	private JTextField txtCustomer;

	/**
	 * Launch the application.
	 */
	public static void In() {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					register window = new register();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public register() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 1292, 750);
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		panel.setBounds(0, 0, 1276, 711);
		frame.setLocationRelativeTo(null);
		panel.setBorder(new LineBorder(new Color(128, 128, 128), 5));
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel_1_2_2 = new JLabel("");
		lblNewLabel_1_2_2.setIcon(new ImageIcon("C:\\Users\\Mike\\Downloads\\bg-removebg-preview (1).png"));
		lblNewLabel_1_2_2.setBounds(1124, 386, 147, 323);
		panel.add(lblNewLabel_1_2_2);

		JLabel lblNewLabel_1_2 = new JLabel("");
		lblNewLabel_1_2.setIcon(new ImageIcon("C:\\Users\\Mike\\Downloads\\bg-removebg-preview (1).png"));
		lblNewLabel_1_2.setBounds(6, 386, 564, 323);
		panel.add(lblNewLabel_1_2);

		JLabel lblNewLabel_1_2_1 = new JLabel("");
		lblNewLabel_1_2_1.setIcon(new ImageIcon("C:\\Users\\Mike\\Downloads\\bg-removebg-preview (1).png"));
		lblNewLabel_1_2_1.setBounds(567, 386, 564, 323);
		panel.add(lblNewLabel_1_2_1);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(47, 79, 79));
		panel_1.setBounds(242, 73, 800, 377);
		panel.add(panel_1);
		panel_1.setLayout(null);

		JLabel lblNewLabel = new JLabel("WELCOME ");
		lblNewLabel.setForeground(new Color(255, 250, 250));
		lblNewLabel.setFont(new Font("Georgia", Font.PLAIN, 63));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(422, 63, 353, 71);
		panel_1.add(lblNewLabel);

		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(new Color(47, 79, 79), 5));
		panel_2.setBounds(0, 0, 400, 377);
		panel_1.add(panel_2);
		panel_2.setLayout(null);

		JButton btnBackToMainmenu = new JButton("Back to Login Page");
		btnBackToMainmenu.setFocusable(false);
		btnBackToMainmenu.setBackground(new Color(47, 79, 79));
		btnBackToMainmenu.setForeground(new Color(255, 255, 255));
		btnBackToMainmenu.setBounds(223, 248, 152, 23);
		panel_2.add(btnBackToMainmenu);

		JButton btnRegister = new JButton("Register");
		btnRegister.setFocusable(false);
		btnRegister.setForeground(new Color(255, 255, 255));
		btnRegister.setBackground(new Color(47, 79, 79));
		btnRegister.setBounds(105, 248, 89, 23);
		panel_2.add(btnRegister);

		txtCustomer = new JTextField();
		txtCustomer.setBounds(178, 333, 75, 20);

		txtCustomer.setEnabled(false);
		txtCustomer.setText("customer");
		txtCustomer.setEditable(false);
		txtCustomer.setHorizontalAlignment(SwingConstants.LEFT);
		txtCustomer.setForeground(new Color(255, 255, 255));
		txtCustomer.setFont(new Font("Georgia", Font.PLAIN, 11));
		txtCustomer.setColumns(10);
		txtCustomer.setBackground(new Color(47, 79, 79));

		Password = new JTextField();
		Password.setBounds(105, 205, 270, 20);
		panel_2.add(Password);

		Password.getDocument().addDocumentListener(new DocumentListener() {
			private JTextComponent passwordErrorLabel;

			@Override
			public void insertUpdate(DocumentEvent e) {
				validatePassword();
			}

			@Override
			public void removeUpdate(DocumentEvent e) {
				validatePassword();
			}

			@Override
			public void changedUpdate(DocumentEvent e) {
				validatePassword();
			}

			private void validatePassword() {
				String input = Password.getText();

				try {
				    // Check if the input is valid for the password (no spaces or special characters allowed)
				    if (input.matches(".*[\\s~`!@#$%^&*()\\-_=+\\[\\]{};:'\",<.>/?].*")) {
				        throw new IllegalArgumentException();
				    }

				    // Clear the error message if the input is valid
				   
				} catch (IllegalArgumentException ex) {
				    // Display an error message with font size 8 if the input is not valid
				    passwordErrorLabel.setText("Must not contain spaces or special characters.");
				}

			}
		});

		Password.setHorizontalAlignment(SwingConstants.LEFT);
		Password.setForeground(Color.BLACK);
		Password.setFont(new Font("Georgia", Font.PLAIN, 11));
		Password.setColumns(10);
		Password.setBackground(new Color(192, 192, 192));

		username = new JTextField();
		username.setBounds(105, 165, 270, 20);
		panel_2.add(username);

		JLabel usernameErrorLabel = new JLabel(" ");
		usernameErrorLabel.setForeground(Color.RED);
		usernameErrorLabel.setBounds(105, 185, 270, 20);
		usernameErrorLabel.setFont(new Font("Georgia", Font.PLAIN, 10));
		panel_2.add(usernameErrorLabel);

		username.getDocument().addDocumentListener(new DocumentListener() {
			@Override
			public void insertUpdate(DocumentEvent e) {
				validateUsername();
			}

			@Override
			public void removeUpdate(DocumentEvent e) {
				validateUsername();
			}

			@Override
			public void changedUpdate(DocumentEvent e) {
				validateUsername();
			}

			private void validateUsername() {
				String input = username.getText();

				try {
					// Check if the input is valid for the username (no spaces allowed)
					// Check if the input contains spaces
					if (!input.matches("[A-Za-z0-9]{0,8}") || input.contains(" ")) {
						throw new IllegalArgumentException();
					}

					// Clear the error message if the input is valid
					usernameErrorLabel.setText(" ");
				} catch (IllegalArgumentException ex) {
					// Display an error message if the input is not valid
					usernameErrorLabel.setText("Must be 8 characters, using A-Z,a-z,0-9, and no spaces.");
				}
			}
		});

		username.setHorizontalAlignment(SwingConstants.LEFT);
		username.setForeground(Color.BLACK);
		username.setFont(new Font("Georgia", Font.PLAIN, 11));
		username.setColumns(10);
		username.setBackground(new Color(192, 192, 192));

		phone = new JTextField();
		phone.setBounds(105, 125, 270, 20);
		panel_2.add(phone);

		Font errorFont = new Font("Georgia", Font.PLAIN, 10);

		JLabel phoneErrorLabel = new JLabel(" ");
		phoneErrorLabel.setForeground(Color.RED);
		phoneErrorLabel.setBounds(105, 145, 270, 20);
		phoneErrorLabel.setFont(errorFont);
		panel_2.add(phoneErrorLabel);

		phone.getDocument().addDocumentListener(new DocumentListener() {
			@Override
			public void insertUpdate(DocumentEvent e) {
				validateInput();
			}

			@Override
			public void removeUpdate(DocumentEvent e) {
				validateInput();
			}

			@Override
			public void changedUpdate(DocumentEvent e) {
				validateInput();
			}

			private void validateInput() {
				String input = phone.getText();

				try {
					// Check if the input is a valid numeric phone number with exactly 11 digits
					if (!input.matches("\\d{11}")) {
						throw new NumberFormatException();
					}

					// Clear the error message if the input is valid
					phoneErrorLabel.setText(" ");
				} catch (NumberFormatException ex) {
					// Display an error message if the input is not a valid number with exactly 11
					// digits
					phoneErrorLabel.setText("Invalid input. Must be a number with exactly 11 digits.");
				}
			}
		});

		phone.setHorizontalAlignment(SwingConstants.LEFT);
		phone.setForeground(Color.BLACK);
		phone.setFont(new Font("Georgia", Font.PLAIN, 11));
		phone.setColumns(10);
		phone.setBackground(new Color(192, 192, 192));

		phone.setHorizontalAlignment(SwingConstants.LEFT);
		phone.setForeground(Color.BLACK);
		phone.setFont(new Font("Georgia", Font.PLAIN, 11));
		phone.setColumns(10);
		phone.setBackground(new Color(192, 192, 192));

		Location = new JTextField();
		Location.setBounds(105, 87, 270, 20);
		panel_2.add(Location);
		Location.setHorizontalAlignment(SwingConstants.LEFT);
		Location.setForeground(Color.BLACK);
		Location.setFont(new Font("Georgia", Font.PLAIN, 11));
		Location.setColumns(10);
		Location.setBackground(new Color(192, 192, 192));

		Name = new JTextField();
		Name.setBounds(105, 50, 270, 20);
		panel_2.add(Name);
		Name.setHorizontalAlignment(SwingConstants.LEFT);
		Name.setForeground(Color.BLACK);
		Name.setFont(new Font("Georgia", Font.PLAIN, 11));
		Name.setColumns(10);
		Name.setBackground(new Color(192, 192, 192));

		JLabel lblNewLabel_1 = new JLabel("FullName:");
		lblNewLabel_1.setBounds(22, 50, 68, 14);
		panel_2.add(lblNewLabel_1);
		lblNewLabel_1.setFont(new Font("Georgia", Font.PLAIN, 11));

		JLabel lblNewLabel_1_1_1 = new JLabel("Address:");
		lblNewLabel_1_1_1.setBounds(22, 87, 68, 14);
		panel_2.add(lblNewLabel_1_1_1);
		lblNewLabel_1_1_1.setFont(new Font("Georgia", Font.PLAIN, 11));

		JLabel lblNewLabel_1_1_3 = new JLabel("Contact#:");
		lblNewLabel_1_1_3.setBounds(22, 125, 68, 14);
		panel_2.add(lblNewLabel_1_1_3);
		lblNewLabel_1_1_3.setFont(new Font("Georgia", Font.PLAIN, 11));

		JLabel lblNewLabel_1_1 = new JLabel("UserName:");
		lblNewLabel_1_1.setBounds(22, 165, 68, 14);
		panel_2.add(lblNewLabel_1_1);
		lblNewLabel_1_1.setFont(new Font("Georgia", Font.PLAIN, 11));

		JLabel lblNewLabel_1_1_2 = new JLabel("Password:");
		lblNewLabel_1_1_2.setBounds(22, 208, 68, 14);
		panel_2.add(lblNewLabel_1_1_2);
		lblNewLabel_1_1_2.setFont(new Font("Georgia", Font.PLAIN, 11));

		JLabel lblSignup = new JLabel("SignUp");
		lblSignup.setBounds(160, 6, 89, 30);
		panel_2.add(lblSignup);
		lblSignup.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		btnRegister.addActionListener(new ActionListener() {
			// Assuming you have JTextField objects for each input field: Name, Location,
			// phone, username, Password, txtCustomer

			@Override
			public void actionPerformed(ActionEvent e) {
				String url = "jdbc:mariadb://localhost:3306/pos";
				String user = "root";
				String passWord = "";

				// Check for empty fields
				if (Name.getText().isEmpty() || Location.getText().isEmpty() || phone.getText().isEmpty()
						|| username.getText().isEmpty() || Password.getText().isEmpty()
						|| txtCustomer.getText().isEmpty()) {
					JOptionPane.showMessageDialog(null, "Fill up all the necessary information");
					return; // Exit the method to prevent further execution
				}

				try (Connection connect = DriverManager.getConnection(url, user, passWord)) {
					String sql = "INSERT INTO users" + "(name, location, phone, username, password, usertype)"
							+ "VALUES(?, ?, ?, ?, ?, ?)";

					try (PreparedStatement prepStat = connect.prepareStatement(sql)) {
						prepStat.setString(1, Name.getText());
						prepStat.setString(2, Location.getText());
						prepStat.setString(3, phone.getText());
						prepStat.setString(4, username.getText());
						prepStat.setString(5, Password.getText());
						prepStat.setString(6, txtCustomer.getText());

						int rowsAffected = prepStat.executeUpdate();
						JOptionPane.showMessageDialog(null, "Register successfully","Success",JOptionPane.INFORMATION_MESSAGE);
						System.out.println(rowsAffected + " row(s)");

						// Clear the text fields after successful insertion
						Name.setText("");
						Location.setText("");
						phone.setText("");
						username.setText("");
						Password.setText("");
						txtCustomer.setText("");
						OAI.main(null);
						frame.dispose();
					} catch (SQLException e2) {
						e2.printStackTrace();
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnBackToMainmenu.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				OAI.main(null);
				frame.dispose();

			}
		});
	}
}
