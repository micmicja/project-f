import java.awt.EventQueue;
import java.sql.*;
import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;



import javax.swing.JPasswordField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Color;

public class OAI {

	private JFrame frame;
	private JTextField user;
	private JPasswordField pass;
	private JButton btnRegister;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OAI window = new OAI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public OAI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(0, 128, 128));
		frame.setBackground(new Color(0, 128, 128));
		frame.getContentPane().setForeground(new Color(0, 128, 128));
		frame.setBounds(100, 100, 633, 251);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ea) {
				String userName = user.getText();
				@SuppressWarnings("deprecation")
				String password = pass.getText();
				String userType = null;

				try {
				    Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/projectd", "root", "");

				    // Use PreparedStatement with placeholders to prevent SQL injection
				    String query = "SELECT * FROM users WHERE username = ? AND password = ? LIMIT 1";
				    PreparedStatement st = connection.prepareStatement(query);
				    st.setString(1, userName);
				    st.setString(2, password);

				    ResultSet rs = st.executeQuery();

				    if (rs.next()) {
				        // Retrieve the user type from the ResultSet
				        userType = rs.getString("usertype");

				        // It's safer to use equalsIgnoreCase for user type comparison to handle case differences
				        if ("admin".equalsIgnoreCase(userType)) {
				        	
				        	inventory.In();	
				        	frame.dispose();
				        	
				        	// Perform admin-specific actions here
				        }
				        else if("customer".equalsIgnoreCase(userType)) {
				        	Dashboard.In();
				        	frame.dispose();
				        	
				        }

				        JOptionPane.showMessageDialog(btnNewButton, "You have successfully logged in");
				    } else {
				        JOptionPane.showMessageDialog(btnNewButton, "Wrong Username & Password");
				    }

				    // Close the ResultSet, PreparedStatement, and Connection in a finally block or use try-with-resources
				    rs.close();
				    st.close();
				    connection.close();
				} catch (SQLException sqlException) {
				    sqlException.printStackTrace();
				}

				
			}
		});
		btnNewButton.setBounds(318, 141, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		user = new JTextField();
		user.setBounds(356, 43, 159, 20);
		frame.getContentPane().add(user);
		user.setColumns(10);
		
		pass = new JPasswordField();
		pass.setBounds(356, 96, 159, 20);
		frame.getContentPane().add(pass);
		
		JLabel lblNewLabel = new JLabel("User");
		lblNewLabel.setBounds(312, 46, 34, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(279, 99, 78, 14);
		frame.getContentPane().add(lblPassword);
		
		btnRegister = new JButton("Register");
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				register.In();
			}
		});
		btnRegister.setBounds(438, 141, 89, 23);
		frame.getContentPane().add(btnRegister);
		
	//usertype = new JComboBox<Object>();
		//usertype.setModel(new DefaultComboBoxModel(new String[] {"admin", "Customer"}));
		//usertype.setBounds(97, 155, 79, 23);
		//frame.getContentPane().add(usertype);
		
	
	}
}
