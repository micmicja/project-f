import java.awt.EventQueue;
import java.sql.*;
import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

import com.mysql.jdbc.ResultSet;

import javax.swing.JPasswordField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class OAI {

	private JFrame frame;
	private JTextField user;
	private JPasswordField pass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OAI window = new OAI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public OAI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 281, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ea) {
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/projecd","root","");
					Statement stmt=con.createStatement();
					String sql= "Select * from login where username='"+user.getText()+"' and pass='"+pass.getText().toString()+"'";
					ResultSet rs=(ResultSet) stmt.executeQuery(sql);
					if(rs.next())
					{
						
						JOptionPane.showMessageDialog(null,"login Succesfully");
						inventory.In();
						frame.setVisible(false);
					}
					
					
					else {
						JOptionPane.showMessageDialog(null,"Incorrect username and pass");
					con.close();
					}
				}catch(Exception e) 
				{System.out.print(e);}
				
			}
		});
		btnNewButton.setBounds(87, 196, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		user = new JTextField();
		user.setBounds(87, 55, 89, 20);
		frame.getContentPane().add(user);
		user.setColumns(10);
		
		pass = new JPasswordField();
		pass.setBounds(87, 108, 89, 20);
		frame.getContentPane().add(pass);
		
		JLabel lblNewLabel = new JLabel("User");
		lblNewLabel.setBounds(43, 58, 34, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(10, 111, 78, 14);
		frame.getContentPane().add(lblPassword);
	}
}
