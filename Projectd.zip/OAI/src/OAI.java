import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.border.LineBorder;

public class OAI {

	JFrame frame;
	private JTextField user;
	private JPasswordField pass;
	private JButton btnRegister;
	private JPanel panel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JPanel panel_1;
	private JPanel panel_2;
	private JLabel lblNewLabel_4;
	private JPanel panel_3;
	private JLabel lblNewLabel_5;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					OAI window = new OAI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public OAI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.getContentPane().setBackground(new Color(0, 128, 128));
		frame.setBackground(new Color(0, 128, 128));
		frame.getContentPane().setForeground(new Color(0, 128, 128));
		frame.setBounds(100, 100, 1292, 750);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBorder(new LineBorder(new Color(128, 128, 128), 5));
		panel.setBounds(0, 0, 1276, 711);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\Mike\\Downloads\\bg-removebg-preview (1).png"));
		lblNewLabel_2.setBounds(565, 386, 564, 323);
		panel.add(lblNewLabel_2);

		lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\Mike\\Downloads\\bg-removebg-preview (1).png"));
		lblNewLabel_1.setBounds(6, 386, 564, 323);
		panel.add(lblNewLabel_1);

		lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\Mike\\Downloads\\bg-removebg-preview (1).png"));
		lblNewLabel_3.setBounds(1120, 386, 150, 323);
		panel.add(lblNewLabel_3);

		panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBounds(242, 73, 800, 377);
		panel.add(panel_1);
		panel_1.setLayout(null);

		panel_3 = new JPanel();
		panel_3.setBackground(new Color(47, 79, 79));
		panel_3.setBounds(422, 0, 378, 377);
		panel_1.add(panel_3);
		panel_3.setLayout(null);

		JButton btnNewButton = new JButton("Login");
		btnNewButton.setFocusable(false);
		btnNewButton.setBounds(111, 212, 99, 23);
		panel_3.add(btnNewButton);
		btnNewButton.setFont(new Font("Georgia", Font.PLAIN, 11));
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ea) {
				String userName = user.getText();
				@SuppressWarnings("deprecation")
				String password = pass.getText();
				String userType = null;
				

				// Check for empty username or password
				if (userName.isEmpty() || password.isEmpty()) {
				    JOptionPane.showMessageDialog(btnNewButton, "Username and password cannot be empty");
				    return; // Exit the method to prevent further execution
				}

				try {
					
				    Connection connection = DriverManager.getConnection("jdbc:mariadb://localhost:3306/pos", "root", "");

				    // Use PreparedStatement with placeholders to prevent SQL injection
				    String query = "SELECT * FROM users WHERE username = ? AND password = ? LIMIT 1";
				    PreparedStatement st = connection.prepareStatement(query);
				    st.setString(1, userName);
				    st.setString(2, password);

				    ResultSet rs = st.executeQuery();

				    if (rs.next()) {
				        // Retrieve the user type from the ResultSet
				        userType = rs.getString("usertype");
				        GlobalVariables.userId = rs.getInt("id");
				        GlobalVariables.name = rs.getString("name");
				        GlobalVariables.loaction = rs.getString("location");
				        GlobalVariables.phone = rs.getString("phone");
				        GlobalVariables.username = rs.getString("username");
				        GlobalVariables.password = rs.getString("password");
				        
				        

				        // It's safer to use equalsIgnoreCase for user type comparison to handle case differences
				        if ("admin".equalsIgnoreCase(userType)) {

				        	inventory.In();
				        	frame.dispose();

				        	// Perform admin-specific actions here
				        }
				        else if("customer".equalsIgnoreCase(userType)) {
				        	Dashboard.In();
				        	frame.dispose();

				        }

				        
				    } else {
				        JOptionPane.showMessageDialog(btnNewButton, "Wrong Username & Password");
				    }

				    // Close the ResultSet, PreparedStatement, and Connection in a finally block or use try-with-resources
				    rs.close();
				    st.close();
				    connection.close();
				} catch (SQLException sqlException) {
				    sqlException.printStackTrace();
				} catch (Exception e) {
				    // Handle other exceptions
				    e.printStackTrace();
				} finally {
				    // Additional cleanup if needed
				}

			}
		});

		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(37, 168, 66, 14);
		panel_3.add(lblPassword);
		lblPassword.setFont(new Font("Georgia", Font.PLAIN, 11));
		lblPassword.setForeground(new Color(255, 255, 255));

		pass = new JPasswordField();
		pass.setBounds(113, 162, 226, 20);
		panel_3.add(pass);

		user = new JTextField();
		user.setBounds(113, 131, 226, 20);
		panel_3.add(user);
		user.setColumns(10);

		btnRegister = new JButton("Register");
		btnRegister.setFocusable(false);
		btnRegister.setBounds(240, 212, 99, 23);
		panel_3.add(btnRegister);
		btnRegister.setFont(new Font("Georgia", Font.PLAIN, 11));
		btnRegister.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				register.In();
			}
		});

		JLabel lblNewLabel = new JLabel("User");
		lblNewLabel.setBounds(37, 137, 34, 14);
		panel_3.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Georgia", Font.PLAIN, 11));
		lblNewLabel.setForeground(new Color(255, 255, 255));

		panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(new Color(47, 79, 79), 5));
		panel_2.setBackground(new Color(255, 255, 255));
		panel_2.setBounds(0, 0, 425, 377);
		panel_1.add(panel_2);
		panel_2.setLayout(null);

		lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setIcon(new ImageIcon("C:\\Users\\Mike\\Downloads\\20231208_210203_0000-removebg-preview.png"));
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setBounds(0, 0, 425, 377);
		panel_2.add(lblNewLabel_5);

		lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setBackground(new Color(47, 79, 79));
		lblNewLabel_4.setBorder(new LineBorder(new Color(47, 79, 79), 5));
		lblNewLabel_4.setIcon(null);
		lblNewLabel_4.setBounds(422, 0, 378, 377);
		panel_1.add(lblNewLabel_4);

	//usertype = new JComboBox<Object>();
		//usertype.setModel(new DefaultComboBoxModel(new String[] {"admin", "Customer"}));
		//usertype.setBounds(97, 155, 79, 23);
		//frame.getContentPane().add(usertype);


	}
}
