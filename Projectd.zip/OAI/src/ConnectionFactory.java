import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.*;

public class ConnectionFactory {
	Statement statement = null;
    ResultSet resultSet = null;
    // create a static instance of the ConnectionFactory class
    private static ConnectionFactory instance = new ConnectionFactory();

    // make the constructor private to prevent other classes from creating new instances
    public ConnectionFactory(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (Exception e) {
            // handle the exception
        }
    }

    // create a public method to get the instance of the ConnectionFactory class
    public static ConnectionFactory getInstance(String sql){
        return instance;
    }

    // create a public method to get a connection object
    public Connection getConn() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/projectd", "root", "");
            System.out.println("Connected successfully.");
        } catch (Exception e) {
            // handle the exception
        }
        return conn;
    }

    //Login verification method
    public boolean checkLogin(String username, String password, String userType){
        String query = "SELECT * FROM users WHERE uname = '" + username + "' AND passw = '" + password + "' AND acces = '" + userType
+ "' LIMIT 1";
       
        try {
        	 resultSet = statement.executeQuery(query);
            if(resultSet.next()) return false;
        } catch (Exception ex) {
        }
        return true;
    }

}