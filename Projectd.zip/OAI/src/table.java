import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class table extends JFrame {
    private JButton uploadButton;
    private JTextField filePathField;

    public table() {
        setTitle("Image Uploader");
        setSize(400, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        uploadButton = new JButton("Upload");
        filePathField = new JTextField(20);

        JPanel panel = new JPanel();
        panel.add(new JLabel("Select Image:"));
        panel.add(filePathField);
        panel.add(uploadButton);

        uploadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                uploadButtonClicked();
            }
        });

        add(panel);
    }

    private void uploadButtonClicked() {
        // Implement the file upload logic here
        String filePath = filePathField.getText();
        // Add your logic to handle the file upload (e.g., using Apache Commons FileUpload)
        System.out.println("File Path: " + filePath);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new table().setVisible(true);
            }
        });
    }
}
