import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLayeredPane;
import javax.swing.JDesktopPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextField;

public class inventory {

	private JFrame frame;
	private JTable table;
	private JPanel Invento;
	private JPanel AddItem;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void In() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					inventory window = new inventory();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public inventory() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.getContentPane().setLayout(null);
		
		JLayeredPane panel = new JLayeredPane();
		panel.setBounds(0, 0, 185, 559);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		
		
		JButton btnNewButton = new JButton("Inventory");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Invento.setVisible(true);
				AddItem.setVisible(false);
			}
		});
		
		
		btnNewButton.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		btnNewButton.setBounds(24, 106, 136, 51);
		panel.add(btnNewButton);
		
		JButton btnAddItem = new JButton("Add Item");
		btnAddItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddItem.setVisible(true);
				Invento.setVisible(false);
			}
		});
		btnAddItem.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		btnAddItem.setBounds(24, 190, 136, 51);
		panel.add(btnAddItem);
		
		JButton btnEditdelete = new JButton("Edit/Delete");
		btnEditdelete.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		btnEditdelete.setBounds(24, 282, 136, 51);
		panel.add(btnEditdelete);
		
		JButton btnAccount = new JButton("Account");
		btnAccount.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		btnAccount.setBounds(24, 374, 136, 51);
		panel.add(btnAccount);
		
		JLayeredPane panel_1 = new JLayeredPane();
		panel_1.setBounds(184, 0, 695, 559);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		AddItem = new JPanel();
		AddItem.setBounds(0, 0, 695, 559);
		panel_1.add(AddItem);
		AddItem.setLayout(null);
		
		JLabel lblAddItem = new JLabel("Add Item");
		lblAddItem.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 30));
		lblAddItem.setBounds(261, 23, 148, 64);
		AddItem.add(lblAddItem);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"nike", "mike", "era"}));
		comboBox.setBounds(250, 154, 159, 22);
		AddItem.add(comboBox);
		
		JLabel lblNewLabel_1 = new JLabel("Product Code");
		lblNewLabel_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(109, 100, 114, 18);
		AddItem.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Product Name");
		lblNewLabel_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1.setBounds(109, 155, 114, 18);
		AddItem.add(lblNewLabel_1_1);
		
		textField = new JTextField();
		textField.setBounds(250, 100, 159, 20);
		AddItem.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Quantity");
		lblNewLabel_1_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1.setBounds(109, 216, 114, 18);
		AddItem.add(lblNewLabel_1_1_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(250, 216, 159, 20);
		AddItem.add(textField_1);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("Cost Price");
		lblNewLabel_1_1_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1.setBounds(109, 276, 114, 18);
		AddItem.add(lblNewLabel_1_1_1_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(250, 276, 159, 20);
		AddItem.add(textField_2);
		
		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("Selling Price");
		lblNewLabel_1_1_1_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_1.setBounds(109, 334, 114, 18);
		AddItem.add(lblNewLabel_1_1_1_1_1);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(250, 334, 159, 20);
		AddItem.add(textField_3);
		
		JLabel lblNewLabel_1_1_1_1_1_1 = new JLabel("Brand");
		lblNewLabel_1_1_1_1_1_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1_1_1.setBounds(109, 396, 114, 18);
		AddItem.add(lblNewLabel_1_1_1_1_1_1);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(250, 396, 159, 20);
		AddItem.add(textField_4);
		
		Invento = new JPanel();
		Invento.setBounds(0, 0, 695, 559);
		panel_1.add(Invento);
		Invento.setLayout(null);
		
		
		JLabel lblNewLabel = new JLabel("Inventory");
		lblNewLabel.setFont(new Font("Sylfaen", Font.PLAIN, 30));
		lblNewLabel.setBounds(253, 11, 148, 64);
		Invento.add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(46, 68, 603, 480);
		Invento.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null},
			},
			new String[] {
				"New column", "New column", "New column", "New column", "New column", "New column", "New column"
			}
		));
		scrollPane.setViewportView(table);
		frame.setBounds(100, 100, 895, 598);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
