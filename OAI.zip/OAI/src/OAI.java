import java.awt.EventQueue;
import java.sql.*;
import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;



import javax.swing.JPasswordField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class OAI {

	private JFrame frame;
	private JTextField user;
	private JPasswordField pass;
	private JComboBox<Object> usertype;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OAI window = new OAI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public OAI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 281, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ea) {
				String sql= "SELECT `uname`, `passw`, `access` FROM `login` WHERE 1 ";
				String user1 = user.getText();
			    String pwd = new String (pass.getPassword());
			    
				String type =(String)usertype.getSelectedItem();
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/test","root","");
					
				
					   PreparedStatement ps = con.prepareStatement(sql);
					   //ps.setString(1, user1);
					  // ps.setString(2, pwd);
					  
					   ResultSet rs = ps.executeQuery(sql);
					    
					    
					        
					        if (rs.next()) {
					        	
								   
					        	if (type.equals("admin")) {  
						            dispose();
						           inventory.In();
						           frame.setVisible(false);
						           } else if (type.equals("cashier")) {  
						            dispose();
						           
							        frame.setVisible(false);
						          }else {
						        	  JOptionPane.showMessageDialog(null,  "User name and password do"
		                                       + " not match! in admin or cashier" ,"ALERT!",
		                                       JOptionPane.ERROR_MESSAGE);
						          }
					          
					          
					        } else {
					          JOptionPane.showMessageDialog(null,  "User name and password do"
					                                       + " not match!","ALERT!",
					                                       JOptionPane.ERROR_MESSAGE); 
					          
					        }
					
				}catch(Exception e) 
				{System.out.print(e);}
				
			}

			private void dispose() {
				// TODO Auto-generated method stub
				
			}
		});
		btnNewButton.setBounds(87, 196, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		user = new JTextField();
		user.setBounds(87, 55, 89, 20);
		frame.getContentPane().add(user);
		user.setColumns(10);
		
		pass = new JPasswordField();
		pass.setBounds(87, 108, 89, 20);
		frame.getContentPane().add(pass);
		
		JLabel lblNewLabel = new JLabel("User");
		lblNewLabel.setBounds(43, 58, 34, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(10, 111, 78, 14);
		frame.getContentPane().add(lblPassword);
		
		usertype = new JComboBox<Object>();
		usertype.setModel(new DefaultComboBoxModel<Object>(new String[] {"admin", "cashier"}));
		usertype.setBounds(97, 155, 79, 23);
		frame.getContentPane().add(usertype);
		
	
	}
}
